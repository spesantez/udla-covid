-- MySQL dump 10.13  Distrib 5.6.40-84.0, for Linux (x86_64)
--
-- Host: localhost    Database: redequip_limeudl
-- ------------------------------------------------------
-- Server version	5.6.40-84.0-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `lsud_answer_l10ns`
--

DROP TABLE IF EXISTS `lsud_answer_l10ns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_answer_l10ns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aid` int(11) NOT NULL,
  `answer` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `language` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lsud_answer_l10ns_idx` (`aid`,`language`)
) ENGINE=MyISAM AUTO_INCREMENT=106 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_answer_l10ns`
--

LOCK TABLES `lsud_answer_l10ns` WRITE;
/*!40000 ALTER TABLE `lsud_answer_l10ns` DISABLE KEYS */;
INSERT INTO `lsud_answer_l10ns` (`id`, `aid`, `answer`, `language`) VALUES (101,101,'Soltero','es'),(100,100,'Divorciado','es'),(99,99,'Masculino','es'),(4,4,'Mestiza','es'),(5,5,'Montubia','es'),(6,6,'Afroecuatoriana','es'),(7,7,'Blanca','es'),(8,8,'Azuay','es'),(9,9,'Bolívar','es'),(10,10,'Cañar','es'),(11,11,'Carchi','es'),(12,12,'Chimborazo','es'),(13,13,'Cotopaxi','es'),(14,14,'El Oro','es'),(15,15,'Esmeraldas','es'),(16,16,'Galápagos','es'),(17,17,'Guayas','es'),(18,18,'Imbabura','es'),(19,19,'Loja','es'),(20,20,'Los Ríos','es'),(21,21,'Manabí','es'),(22,22,'Morona Santiago','es'),(23,23,'Napo','es'),(24,24,'Orellana','es'),(25,25,'Pastaza','es'),(26,26,'Pichincha','es'),(27,27,'Santa Elena','es'),(28,28,'Santo Domingo de los Tsáchilas','es'),(29,29,'Sucumbíos','es'),(30,30,'Tungurahua','es'),(31,31,'Zamora Chinchipe','es'),(32,32,'Casado','es'),(33,33,'Divorciado','es'),(34,34,'Soltero','es'),(35,35,'Viudo','es'),(36,36,'Unión de hecho','es'),(37,37,'Médico rural','es'),(38,38,'Médico postgradista','es'),(39,39,'Médico residente','es'),(40,40,'Médico especialista','es'),(41,41,'Médico general','es'),(42,42,'Enfermera','es'),(43,43,'Técnico','es'),(44,44,'Auxiliar','es'),(45,45,'Directivo','es'),(46,46,'Centro de salud','es'),(47,47,'Hospital','es'),(48,48,'Instituto','es'),(49,49,'Clínica privada','es'),(50,50,'MSP','es'),(51,51,'IESS','es'),(52,52,'ISSFA','es'),(53,53,'ISPOL','es'),(54,54,'Emergencias','es'),(55,55,'Sala de hospitalización COVID','es'),(56,56,'Unidad de Cuidados Intensivos (UCI)','es'),(57,57,'Sala de hospitalización general','es'),(58,58,'Tercer nivel','es'),(59,59,'Cuarto nivel','es'),(60,60,'Técnico','es'),(61,61,'Ninguno','es'),(62,62,'Si','es'),(63,63,'Si, pero no suficiente','es'),(64,64,'No','es'),(65,65,'Si','es'),(66,66,'Si, pero no suficiente','es'),(67,67,'No','es'),(68,68,'Si','es'),(69,69,'No','es'),(70,70,'No de todos','es'),(71,71,'Si','es'),(72,72,'No','es'),(73,73,'No sé','es'),(74,74,'Si','es'),(75,75,'No','es'),(76,76,'Positivo','es'),(77,77,'Negativo','es'),(78,78,'Desconocido','es'),(79,79,'Si','es'),(80,80,'No','es'),(81,81,'Si','es'),(82,82,'No','es'),(83,83,'Sala de hospital','es'),(84,84,'UCI','es'),(85,85,'Si','es'),(86,86,'No','es'),(87,87,'No sé','es'),(88,88,'De acuerdo','es'),(89,89,'Neutral','es'),(90,90,'En desacuerdo','es'),(91,91,'Si','es'),(92,92,'No','es'),(93,93,'De acuerdo','es'),(94,94,'Neutral','es'),(95,95,'En desacuerdo','es'),(96,96,'Nada','es'),(97,97,'Algo','es'),(98,98,'Mucho','es'),(102,102,'Viudo','es'),(103,103,'Unión de hecho','es'),(104,104,'Femenino','es'),(105,105,'Otro','es');
/*!40000 ALTER TABLE `lsud_answer_l10ns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_answers`
--

DROP TABLE IF EXISTS `lsud_answers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_answers` (
  `aid` int(11) NOT NULL AUTO_INCREMENT,
  `qid` int(11) NOT NULL,
  `code` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sortorder` int(11) NOT NULL,
  `assessment_value` int(11) NOT NULL DEFAULT '0',
  `scale_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`aid`),
  UNIQUE KEY `lsud_answers_idx` (`qid`,`code`,`scale_id`),
  KEY `lsud_answers_idx2` (`sortorder`)
) ENGINE=MyISAM AUTO_INCREMENT=106 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_answers`
--

LOCK TABLES `lsud_answers` WRITE;
/*!40000 ALTER TABLE `lsud_answers` DISABLE KEYS */;
INSERT INTO `lsud_answers` (`aid`, `qid`, `code`, `sortorder`, `assessment_value`, `scale_id`) VALUES (99,83,'1',1,1,0),(4,3,'1',1,1,0),(5,3,'2',2,2,0),(6,3,'3',3,0,0),(7,3,'4',4,0,0),(8,4,'1',1,0,0),(9,4,'2',2,0,0),(10,4,'3',3,0,0),(11,4,'4',4,0,0),(12,4,'5',5,0,0),(13,4,'6',6,0,0),(14,4,'7',7,0,0),(15,4,'8',8,0,0),(16,4,'9',9,0,0),(17,4,'10',10,0,0),(18,4,'11',11,0,0),(19,4,'12',12,0,0),(20,4,'13',13,0,0),(21,4,'14',14,0,0),(22,4,'15',15,0,0),(23,4,'16',16,0,0),(24,4,'17',17,0,0),(25,4,'18',18,0,0),(26,4,'19',19,0,0),(27,4,'20',20,0,0),(28,4,'21',21,0,0),(29,4,'22',22,0,0),(30,4,'23',23,0,0),(31,4,'24',24,0,0),(32,6,'F',1,1,0),(33,6,'M',2,2,0),(34,6,'O',3,3,0),(35,6,'F01',4,0,0),(36,6,'F02',5,0,0),(37,7,'1',1,1,0),(38,7,'2',2,2,0),(39,7,'3',3,3,0),(40,7,'4',4,0,0),(41,7,'5',5,0,0),(42,7,'6',6,0,0),(43,7,'7',7,0,0),(44,7,'8',8,0,0),(45,7,'9',9,0,0),(46,8,'1',1,1,0),(47,8,'2',2,2,0),(48,8,'3',3,0,0),(49,8,'4',4,0,0),(50,9,'1',1,1,0),(51,9,'2',2,2,0),(52,9,'3',3,0,0),(53,9,'4',4,0,0),(54,10,'1',1,1,0),(55,10,'2',2,2,0),(56,10,'3',3,0,0),(57,10,'4',4,0,0),(58,11,'1',1,1,0),(59,11,'2',2,2,0),(60,11,'3',3,0,0),(61,11,'4',4,0,0),(62,12,'1',1,0,0),(63,12,'2',2,0,0),(64,12,'3',3,0,0),(65,13,'1',1,0,0),(66,13,'2',2,0,0),(67,13,'3',3,0,0),(68,14,'1',1,0,0),(69,14,'2',2,0,0),(70,14,'3',3,0,0),(71,15,'1',1,0,0),(72,15,'2',2,0,0),(73,15,'3',3,0,0),(74,16,'1',1,0,0),(75,16,'2',2,0,0),(76,17,'1',1,0,0),(77,17,'2',2,0,0),(78,17,'3',3,0,0),(79,18,'1',1,0,0),(80,18,'2',2,0,0),(81,19,'1',1,0,0),(82,19,'2',2,0,0),(83,20,'1',1,1,0),(84,20,'2',2,2,0),(85,22,'1',1,0,0),(86,22,'2',2,0,0),(87,22,'3',3,0,0),(88,23,'1',1,0,0),(89,23,'2',2,0,0),(90,23,'3',3,0,0),(91,24,'1',1,0,0),(92,24,'2',2,0,0),(93,25,'1',1,0,0),(94,25,'2',2,0,0),(95,25,'3',3,0,0),(96,26,'1',1,0,0),(97,26,'2',2,0,0),(98,26,'3',3,0,0),(105,83,'3',3,3,0),(104,83,'2',2,2,0);
/*!40000 ALTER TABLE `lsud_answers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_assessments`
--

DROP TABLE IF EXISTS `lsud_assessments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_assessments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) NOT NULL DEFAULT '0',
  `scope` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gid` int(11) NOT NULL DEFAULT '0',
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `minimum` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `maximum` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `language` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en',
  PRIMARY KEY (`id`,`language`),
  KEY `lsud_assessments_idx2` (`sid`),
  KEY `lsud_assessments_idx3` (`gid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_assessments`
--

LOCK TABLES `lsud_assessments` WRITE;
/*!40000 ALTER TABLE `lsud_assessments` DISABLE KEYS */;
/*!40000 ALTER TABLE `lsud_assessments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_asset_version`
--

DROP TABLE IF EXISTS `lsud_asset_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_asset_version` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `path` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_asset_version`
--

LOCK TABLES `lsud_asset_version` WRITE;
/*!40000 ALTER TABLE `lsud_asset_version` DISABLE KEYS */;
INSERT INTO `lsud_asset_version` (`id`, `path`, `version`) VALUES (1,'/home/redequip/public_html/encuestas/upload/themes/survey/udla_vanilla',1);
/*!40000 ALTER TABLE `lsud_asset_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_boxes`
--

DROP TABLE IF EXISTS `lsud_boxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_boxes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `position` int(11) DEFAULT NULL,
  `url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `ico` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `desc` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `page` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `usergroup` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_boxes`
--

LOCK TABLES `lsud_boxes` WRITE;
/*!40000 ALTER TABLE `lsud_boxes` DISABLE KEYS */;
INSERT INTO `lsud_boxes` (`id`, `position`, `url`, `title`, `ico`, `desc`, `page`, `usergroup`) VALUES (1,1,'admin/survey/sa/newsurvey','Create survey','icon-add','Create a new survey','welcome',-2),(2,2,'admin/survey/sa/listsurveys','List surveys','icon-list','List available surveys','welcome',-1),(3,3,'admin/globalsettings','Global settings','icon-settings','Edit global settings','welcome',-2),(4,4,'admin/update','ComfortUpdate','icon-shield','Stay safe and up to date','welcome',-2),(5,5,'https://account.limesurvey.org/limestore','LimeStore','fa fa-cart-plus','LimeSurvey extension marketplace','welcome',-2),(6,6,'admin/themeoptions','Themes','icon-templates','Themes','welcome',-2);
/*!40000 ALTER TABLE `lsud_boxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_conditions`
--

DROP TABLE IF EXISTS `lsud_conditions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_conditions` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `qid` int(11) NOT NULL DEFAULT '0',
  `cqid` int(11) NOT NULL DEFAULT '0',
  `cfieldname` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `method` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `scenario` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`cid`),
  KEY `lsud_conditions_idx` (`qid`),
  KEY `lsud_conditions_idx3` (`cqid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_conditions`
--

LOCK TABLES `lsud_conditions` WRITE;
/*!40000 ALTER TABLE `lsud_conditions` DISABLE KEYS */;
/*!40000 ALTER TABLE `lsud_conditions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_defaultvalue_l10ns`
--

DROP TABLE IF EXISTS `lsud_defaultvalue_l10ns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_defaultvalue_l10ns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dvid` int(11) NOT NULL DEFAULT '0',
  `language` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `defaultvalue` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `lsud_idx1_defaultvalue_ls` (`dvid`,`language`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_defaultvalue_l10ns`
--

LOCK TABLES `lsud_defaultvalue_l10ns` WRITE;
/*!40000 ALTER TABLE `lsud_defaultvalue_l10ns` DISABLE KEYS */;
/*!40000 ALTER TABLE `lsud_defaultvalue_l10ns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_defaultvalues`
--

DROP TABLE IF EXISTS `lsud_defaultvalues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_defaultvalues` (
  `dvid` int(11) NOT NULL AUTO_INCREMENT,
  `qid` int(11) NOT NULL DEFAULT '0',
  `scale_id` int(11) NOT NULL DEFAULT '0',
  `sqid` int(11) NOT NULL DEFAULT '0',
  `specialtype` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`dvid`),
  KEY `lsud_idx1_defaultvalue` (`qid`,`scale_id`,`sqid`,`specialtype`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_defaultvalues`
--

LOCK TABLES `lsud_defaultvalues` WRITE;
/*!40000 ALTER TABLE `lsud_defaultvalues` DISABLE KEYS */;
/*!40000 ALTER TABLE `lsud_defaultvalues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_expression_errors`
--

DROP TABLE IF EXISTS `lsud_expression_errors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_expression_errors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `errortime` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sid` int(11) DEFAULT NULL,
  `gid` int(11) DEFAULT NULL,
  `qid` int(11) DEFAULT NULL,
  `gseq` int(11) DEFAULT NULL,
  `qseq` int(11) DEFAULT NULL,
  `type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `eqn` text COLLATE utf8mb4_unicode_ci,
  `prettyprint` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_expression_errors`
--

LOCK TABLES `lsud_expression_errors` WRITE;
/*!40000 ALTER TABLE `lsud_expression_errors` DISABLE KEYS */;
/*!40000 ALTER TABLE `lsud_expression_errors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_failed_login_attempts`
--

DROP TABLE IF EXISTS `lsud_failed_login_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_failed_login_attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_attempt` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number_attempts` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_failed_login_attempts`
--

LOCK TABLES `lsud_failed_login_attempts` WRITE;
/*!40000 ALTER TABLE `lsud_failed_login_attempts` DISABLE KEYS */;
/*!40000 ALTER TABLE `lsud_failed_login_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_group_l10ns`
--

DROP TABLE IF EXISTS `lsud_group_l10ns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_group_l10ns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gid` int(11) NOT NULL,
  `group_name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `language` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lsud_idx1_group_ls` (`gid`,`language`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_group_l10ns`
--

LOCK TABLES `lsud_group_l10ns` WRITE;
/*!40000 ALTER TABLE `lsud_group_l10ns` DISABLE KEYS */;
INSERT INTO `lsud_group_l10ns` (`id`, `gid`, `group_name`, `description`, `language`) VALUES (1,1,'Variables sociodemográficas','','es'),(2,2,'Conocimientos','','es'),(3,3,'Actitudes','','es'),(4,4,'Prácticas','','es'),(5,5,'Riesgo percibido','','es');
/*!40000 ALTER TABLE `lsud_group_l10ns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_groups`
--

DROP TABLE IF EXISTS `lsud_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_groups` (
  `gid` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) NOT NULL DEFAULT '0',
  `group_order` int(11) NOT NULL DEFAULT '0',
  `randomization_group` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `grelevance` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`gid`),
  KEY `lsud_idx1_groups` (`sid`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_groups`
--

LOCK TABLES `lsud_groups` WRITE;
/*!40000 ALTER TABLE `lsud_groups` DISABLE KEYS */;
INSERT INTO `lsud_groups` (`gid`, `sid`, `group_order`, `randomization_group`, `grelevance`) VALUES (1,855621,1,'',''),(2,855621,2,'',''),(3,855621,3,'',''),(4,855621,4,'',''),(5,855621,5,'','');
/*!40000 ALTER TABLE `lsud_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_label_l10ns`
--

DROP TABLE IF EXISTS `lsud_label_l10ns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_label_l10ns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label_id` int(11) NOT NULL,
  `title` text COLLATE utf8mb4_unicode_ci,
  `language` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_label_l10ns`
--

LOCK TABLES `lsud_label_l10ns` WRITE;
/*!40000 ALTER TABLE `lsud_label_l10ns` DISABLE KEYS */;
/*!40000 ALTER TABLE `lsud_label_l10ns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_labels`
--

DROP TABLE IF EXISTS `lsud_labels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_labels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) NOT NULL DEFAULT '0',
  `code` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `sortorder` int(11) NOT NULL,
  `assessment_value` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `lsud_idx1_labels` (`code`),
  KEY `lsud_idx2_labels` (`sortorder`),
  KEY `lsud_idx4_labels` (`lid`,`sortorder`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_labels`
--

LOCK TABLES `lsud_labels` WRITE;
/*!40000 ALTER TABLE `lsud_labels` DISABLE KEYS */;
/*!40000 ALTER TABLE `lsud_labels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_labelsets`
--

DROP TABLE IF EXISTS `lsud_labelsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_labelsets` (
  `lid` int(11) NOT NULL AUTO_INCREMENT,
  `label_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `languages` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`lid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_labelsets`
--

LOCK TABLES `lsud_labelsets` WRITE;
/*!40000 ALTER TABLE `lsud_labelsets` DISABLE KEYS */;
/*!40000 ALTER TABLE `lsud_labelsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_map_tutorial_users`
--

DROP TABLE IF EXISTS `lsud_map_tutorial_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_map_tutorial_users` (
  `tid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `taken` int(11) DEFAULT '1',
  PRIMARY KEY (`uid`,`tid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_map_tutorial_users`
--

LOCK TABLES `lsud_map_tutorial_users` WRITE;
/*!40000 ALTER TABLE `lsud_map_tutorial_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `lsud_map_tutorial_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_notifications`
--

DROP TABLE IF EXISTS `lsud_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entity` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'new',
  `importance` int(11) NOT NULL DEFAULT '1',
  `display_class` varchar(31) COLLATE utf8mb4_unicode_ci DEFAULT 'default',
  `hash` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `first_read` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lsud_notifications_pk` (`entity`,`entity_id`,`status`),
  KEY `lsud_idx1_notifications` (`hash`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_notifications`
--

LOCK TABLES `lsud_notifications` WRITE;
/*!40000 ALTER TABLE `lsud_notifications` DISABLE KEYS */;
INSERT INTO `lsud_notifications` (`id`, `entity`, `entity_id`, `title`, `message`, `status`, `importance`, `display_class`, `hash`, `created`, `first_read`) VALUES (1,'user',1,'SSL no forzado','<span class=\"fa fa-exclamation-circle text-warning\"></span>&nbsp;Advertencia: aplique la encriptación SSL en la Configuración global/Seguridad después de que el SSL esté configurado correctamente en su servidor web.','new',1,'default','326394c7542e4add34c03425df05e58e80649cce6cd7ab6d373e4626001c6226','2020-11-20 12:32:09','2020-11-20 12:32:25'),(2,'user',1,'LimeSurvey theme editor','Welcome to the theme editor of LimeSurvey. To get an overview of new functionality and possibilities, please visit the <a target=\"_blank\" href=\"https://manualv4.limesurvey.org/LimeSurvey_Manual\"> LimeSurvey manual </a>. For further questions and information, feel free to post your questions on the <a target=\"_blank\" href=\"https://forums.limesurvey.org\"> LimeSurvey forums </a>.','read',1,'default','b4121aa783059be1c16740534c4d63ae03963c59275775a1f7d0e76586188c1f','2020-11-20 15:35:21','2020-11-20 15:35:29');
/*!40000 ALTER TABLE `lsud_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_old_survey_855621_20201120154443`
--

DROP TABLE IF EXISTS `lsud_old_survey_855621_20201120154443`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_old_survey_855621_20201120154443` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `submitdate` datetime DEFAULT NULL,
  `lastpage` int(11) DEFAULT NULL,
  `startlanguage` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `seed` varchar(31) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `startdate` datetime NOT NULL,
  `datestamp` datetime NOT NULL,
  `ipaddr` text COLLATE utf8mb4_unicode_ci,
  `refurl` text COLLATE utf8mb4_unicode_ci,
  `855621X1X1` decimal(30,10) DEFAULT NULL,
  `855621X1X83` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X1X3` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X1X3other` text COLLATE utf8mb4_unicode_ci,
  `855621X1X4` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X1X6` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X1X7` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X1X7other` text COLLATE utf8mb4_unicode_ci,
  `855621X1X8` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X1X8other` text COLLATE utf8mb4_unicode_ci,
  `855621X1X9` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X1X9other` text COLLATE utf8mb4_unicode_ci,
  `855621X1X10` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X1X10other` text COLLATE utf8mb4_unicode_ci,
  `855621X1X11` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X1X11other` text COLLATE utf8mb4_unicode_ci,
  `855621X1X12` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X1X13` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X1X14` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X1X15` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X1X16` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X1X17` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X1X18` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X1X19` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X1X20` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X1X20other` text COLLATE utf8mb4_unicode_ci,
  `855621X1X21` decimal(30,10) DEFAULT NULL,
  `855621X2X221` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X2X222` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X2X223` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X2X224` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X2X225` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X2X226` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X2X227` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X2X228` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X2X229` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X2X2210` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X2X2211` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X2X2212` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X2X2213` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X2X2214` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X2X2215` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X2X2216` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X2X2217` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X2X2218` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X2X2219` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X2X2220` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X3X231` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X3X232` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X3X233` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X3X234` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X3X235` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X3X236` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X3X237` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X3X238` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X4X241` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X4X242` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X4X243` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X4X244` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X4X245` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X4X246` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X4X247` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X4X248` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X4X249` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X4X2410` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X4X2411` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X4X2412` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X4X2413` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X4X2414` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X4X2415` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X5X251` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X5X252` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X5X253` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X5X254` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X5X255` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X5X256` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X5X257` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X5X258` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X5X259` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X5X2510` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X5X2511` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X5X2512` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X5X2612` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_old_survey_855621_20201120154443`
--

LOCK TABLES `lsud_old_survey_855621_20201120154443` WRITE;
/*!40000 ALTER TABLE `lsud_old_survey_855621_20201120154443` DISABLE KEYS */;
/*!40000 ALTER TABLE `lsud_old_survey_855621_20201120154443` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_old_survey_855621_timings_20201120154443`
--

DROP TABLE IF EXISTS `lsud_old_survey_855621_timings_20201120154443`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_old_survey_855621_timings_20201120154443` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `interviewtime` float DEFAULT NULL,
  `855621X1time` float DEFAULT NULL,
  `855621X1X1time` float DEFAULT NULL,
  `855621X1X83time` float DEFAULT NULL,
  `855621X1X3time` float DEFAULT NULL,
  `855621X1X4time` float DEFAULT NULL,
  `855621X1X6time` float DEFAULT NULL,
  `855621X1X7time` float DEFAULT NULL,
  `855621X1X8time` float DEFAULT NULL,
  `855621X1X9time` float DEFAULT NULL,
  `855621X1X10time` float DEFAULT NULL,
  `855621X1X11time` float DEFAULT NULL,
  `855621X1X12time` float DEFAULT NULL,
  `855621X1X13time` float DEFAULT NULL,
  `855621X1X14time` float DEFAULT NULL,
  `855621X1X15time` float DEFAULT NULL,
  `855621X1X16time` float DEFAULT NULL,
  `855621X1X17time` float DEFAULT NULL,
  `855621X1X18time` float DEFAULT NULL,
  `855621X1X19time` float DEFAULT NULL,
  `855621X1X20time` float DEFAULT NULL,
  `855621X1X21time` float DEFAULT NULL,
  `855621X2time` float DEFAULT NULL,
  `855621X2X22time` float DEFAULT NULL,
  `855621X3time` float DEFAULT NULL,
  `855621X3X23time` float DEFAULT NULL,
  `855621X4time` float DEFAULT NULL,
  `855621X4X24time` float DEFAULT NULL,
  `855621X5time` float DEFAULT NULL,
  `855621X5X25time` float DEFAULT NULL,
  `855621X5X26time` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_old_survey_855621_timings_20201120154443`
--

LOCK TABLES `lsud_old_survey_855621_timings_20201120154443` WRITE;
/*!40000 ALTER TABLE `lsud_old_survey_855621_timings_20201120154443` DISABLE KEYS */;
/*!40000 ALTER TABLE `lsud_old_survey_855621_timings_20201120154443` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_participant_attribute`
--

DROP TABLE IF EXISTS `lsud_participant_attribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_participant_attribute` (
  `participant_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribute_id` int(11) NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`participant_id`,`attribute_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_participant_attribute`
--

LOCK TABLES `lsud_participant_attribute` WRITE;
/*!40000 ALTER TABLE `lsud_participant_attribute` DISABLE KEYS */;
/*!40000 ALTER TABLE `lsud_participant_attribute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_participant_attribute_names`
--

DROP TABLE IF EXISTS `lsud_participant_attribute_names`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_participant_attribute_names` (
  `attribute_id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_type` varchar(4) COLLATE utf8mb4_unicode_ci NOT NULL,
  `defaultname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `visible` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `encrypted` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `core_attribute` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`attribute_id`,`attribute_type`),
  KEY `lsud_idx_participant_attribute_names` (`attribute_id`,`attribute_type`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_participant_attribute_names`
--

LOCK TABLES `lsud_participant_attribute_names` WRITE;
/*!40000 ALTER TABLE `lsud_participant_attribute_names` DISABLE KEYS */;
INSERT INTO `lsud_participant_attribute_names` (`attribute_id`, `attribute_type`, `defaultname`, `visible`, `encrypted`, `core_attribute`) VALUES (1,'TB','firstname','TRUE','Y','Y'),(2,'TB','lastname','TRUE','Y','Y'),(3,'TB','email','TRUE','Y','Y');
/*!40000 ALTER TABLE `lsud_participant_attribute_names` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_participant_attribute_names_lang`
--

DROP TABLE IF EXISTS `lsud_participant_attribute_names_lang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_participant_attribute_names_lang` (
  `attribute_id` int(11) NOT NULL,
  `attribute_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lang` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`attribute_id`,`lang`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_participant_attribute_names_lang`
--

LOCK TABLES `lsud_participant_attribute_names_lang` WRITE;
/*!40000 ALTER TABLE `lsud_participant_attribute_names_lang` DISABLE KEYS */;
/*!40000 ALTER TABLE `lsud_participant_attribute_names_lang` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_participant_attribute_values`
--

DROP TABLE IF EXISTS `lsud_participant_attribute_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_participant_attribute_values` (
  `value_id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_id` int(11) NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`value_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_participant_attribute_values`
--

LOCK TABLES `lsud_participant_attribute_values` WRITE;
/*!40000 ALTER TABLE `lsud_participant_attribute_values` DISABLE KEYS */;
/*!40000 ALTER TABLE `lsud_participant_attribute_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_participant_shares`
--

DROP TABLE IF EXISTS `lsud_participant_shares`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_participant_shares` (
  `participant_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `share_uid` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  `can_edit` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`participant_id`,`share_uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_participant_shares`
--

LOCK TABLES `lsud_participant_shares` WRITE;
/*!40000 ALTER TABLE `lsud_participant_shares` DISABLE KEYS */;
/*!40000 ALTER TABLE `lsud_participant_shares` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_participants`
--

DROP TABLE IF EXISTS `lsud_participants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_participants` (
  `participant_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `firstname` text COLLATE utf8mb4_unicode_ci,
  `lastname` text COLLATE utf8mb4_unicode_ci,
  `email` text COLLATE utf8mb4_unicode_ci,
  `language` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `blacklisted` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_uid` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`participant_id`),
  KEY `lsud_idx3_participants` (`language`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_participants`
--

LOCK TABLES `lsud_participants` WRITE;
/*!40000 ALTER TABLE `lsud_participants` DISABLE KEYS */;
/*!40000 ALTER TABLE `lsud_participants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_permissions`
--

DROP TABLE IF EXISTS `lsud_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entity` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `permission` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `create_p` int(11) NOT NULL DEFAULT '0',
  `read_p` int(11) NOT NULL DEFAULT '0',
  `update_p` int(11) NOT NULL DEFAULT '0',
  `delete_p` int(11) NOT NULL DEFAULT '0',
  `import_p` int(11) NOT NULL DEFAULT '0',
  `export_p` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `lsud_idx1_permissions` (`entity_id`,`entity`,`permission`,`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_permissions`
--

LOCK TABLES `lsud_permissions` WRITE;
/*!40000 ALTER TABLE `lsud_permissions` DISABLE KEYS */;
INSERT INTO `lsud_permissions` (`id`, `entity`, `entity_id`, `uid`, `permission`, `create_p`, `read_p`, `update_p`, `delete_p`, `import_p`, `export_p`) VALUES (1,'global',0,1,'superadmin',0,1,0,0,0,0),(2,'survey',855621,1,'surveyactivation',0,0,1,0,0,0),(3,'survey',855621,1,'surveysettings',0,1,1,0,0,0),(4,'survey',855621,1,'surveycontent',1,1,1,1,1,1),(5,'survey',855621,1,'quotas',1,1,1,1,0,0),(6,'survey',855621,1,'surveylocale',0,1,1,0,0,0),(7,'survey',855621,1,'survey',0,1,0,1,0,0),(8,'survey',855621,1,'statistics',0,1,0,0,0,0),(9,'survey',855621,1,'assessments',1,1,1,1,0,0),(10,'survey',855621,1,'tokens',1,1,1,1,1,1),(11,'survey',855621,1,'responses',1,1,1,1,1,1),(12,'survey',855621,1,'surveysecurity',1,1,1,1,0,0),(13,'survey',855621,1,'translations',0,1,1,0,0,0);
/*!40000 ALTER TABLE `lsud_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_permissiontemplates`
--

DROP TABLE IF EXISTS `lsud_permissiontemplates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_permissiontemplates` (
  `ptid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(127) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `renewed_last` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  PRIMARY KEY (`ptid`),
  UNIQUE KEY `lsud_idx1_name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_permissiontemplates`
--

LOCK TABLES `lsud_permissiontemplates` WRITE;
/*!40000 ALTER TABLE `lsud_permissiontemplates` DISABLE KEYS */;
/*!40000 ALTER TABLE `lsud_permissiontemplates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_plugin_settings`
--

DROP TABLE IF EXISTS `lsud_plugin_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_plugin_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plugin_id` int(11) NOT NULL,
  `model` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `model_id` int(11) DEFAULT NULL,
  `key` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_plugin_settings`
--

LOCK TABLES `lsud_plugin_settings` WRITE;
/*!40000 ALTER TABLE `lsud_plugin_settings` DISABLE KEYS */;
INSERT INTO `lsud_plugin_settings` (`id`, `plugin_id`, `model`, `model_id`, `key`, `value`) VALUES (1,1,NULL,NULL,'next_extension_update_check','\"2020-11-23 16:01:24\"');
/*!40000 ALTER TABLE `lsud_plugin_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_plugins`
--

DROP TABLE IF EXISTS `lsud_plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `plugin_type` varchar(6) COLLATE utf8mb4_unicode_ci DEFAULT 'user',
  `active` int(11) NOT NULL DEFAULT '0',
  `priority` int(11) NOT NULL DEFAULT '0',
  `version` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `load_error` int(11) DEFAULT '0',
  `load_error_message` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_plugins`
--

LOCK TABLES `lsud_plugins` WRITE;
/*!40000 ALTER TABLE `lsud_plugins` DISABLE KEYS */;
INSERT INTO `lsud_plugins` (`id`, `name`, `plugin_type`, `active`, `priority`, `version`, `load_error`, `load_error_message`) VALUES (1,'UpdateCheck','core',1,0,'1.0.0',0,NULL),(2,'PasswordRequirement','core',1,0,'1.0.0',0,NULL),(3,'Authdb','core',1,0,'1.0.0',0,NULL),(4,'AuthLDAP','core',0,0,'1.0.0',0,NULL),(5,'AuditLog','core',0,0,'1.0.0',0,NULL),(6,'Authwebserver','core',0,0,'1.0.0',0,NULL),(7,'ExportR','core',1,0,'1.0.0',0,NULL),(8,'ExportSTATAxml','core',1,0,'1.0.0',0,NULL),(9,'oldUrlCompat','core',0,0,'1.0.0',0,NULL),(10,'expressionQuestionHelp','core',0,0,'1.0.0',0,NULL),(11,'expressionQuestionForAll','core',0,0,'1.0.0',0,NULL),(12,'expressionFixedDbVar','core',0,0,'1.0.0',0,NULL),(13,'customToken','core',0,0,'1.0.1',0,NULL),(14,'mailSenderToFrom','core',0,0,'1.0.0',0,NULL);
/*!40000 ALTER TABLE `lsud_plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_question_attributes`
--

DROP TABLE IF EXISTS `lsud_question_attributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_question_attributes` (
  `qaid` int(11) NOT NULL AUTO_INCREMENT,
  `qid` int(11) NOT NULL DEFAULT '0',
  `attribute` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `language` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`qaid`),
  KEY `lsud_idx1_question_attributes` (`qid`),
  KEY `lsud_idx2_question_attributes` (`attribute`)
) ENGINE=MyISAM AUTO_INCREMENT=445 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_question_attributes`
--

LOCK TABLES `lsud_question_attributes` WRITE;
/*!40000 ALTER TABLE `lsud_question_attributes` DISABLE KEYS */;
INSERT INTO `lsud_question_attributes` (`qaid`, `qid`, `attribute`, `value`, `language`) VALUES (1,1,'id','1',NULL),(2,1,'hidden','0',NULL),(3,1,'hide_tip','0',NULL),(4,1,'input_size','33',NULL),(5,1,'max_num_value_n','80',NULL),(6,1,'maximum_chars','2',NULL),(7,1,'min_num_value_n','18',NULL),(8,1,'num_value_int_only','1',NULL),(9,1,'page_break','0',NULL),(10,1,'public_statistics','0',NULL),(11,1,'statistics_graphtype','0',NULL),(12,1,'statistics_showgraph','1',NULL),(433,83,'time_limit_message_delay','',NULL),(432,83,'time_limit_timer_style','',NULL),(431,83,'time_limit_countdown_message','',NULL),(430,83,'time_limit_disable_prev','0',NULL),(429,83,'time_limit_disable_next','0',NULL),(428,83,'time_limit_action','1',NULL),(427,83,'time_limit','',NULL),(426,83,'statistics_graphtype','0',NULL),(425,83,'statistics_showgraph','1',NULL),(424,83,'public_statistics','0',NULL),(423,83,'scale_export','0',NULL),(31,3,'id','17',NULL),(32,3,'alphasort','0',NULL),(33,3,'array_filter_style','0',NULL),(34,3,'hidden','0',NULL),(35,3,'hide_tip','1',NULL),(36,3,'other_comment_mandatory','1',NULL),(37,3,'other_numbers_only','0',NULL),(38,3,'other_replace_text','Otro (especifique)',NULL),(39,3,'page_break','0',NULL),(40,3,'public_statistics','0',NULL),(41,3,'random_order','0',NULL),(42,3,'scale_export','0',NULL),(43,3,'statistics_graphtype','0',NULL),(44,3,'statistics_showgraph','1',NULL),(45,3,'time_limit_action','1',NULL),(46,3,'time_limit_disable_next','0',NULL),(47,3,'time_limit_disable_prev','0',NULL),(48,4,'id','4',NULL),(49,4,'alphasort','0',NULL),(50,4,'dropdown_prefix','0',NULL),(51,4,'hidden','0',NULL),(52,4,'hide_tip','0',NULL),(53,4,'other_comment_mandatory','0',NULL),(54,4,'page_break','0',NULL),(55,4,'public_statistics','0',NULL),(56,4,'random_order','0',NULL),(57,4,'scale_export','0',NULL),(58,4,'statistics_graphtype','0',NULL),(59,4,'statistics_showgraph','1',NULL),(60,4,'time_limit_action','1',NULL),(61,4,'time_limit_disable_next','0',NULL),(62,4,'time_limit_disable_prev','0',NULL),(422,83,'page_break','0',NULL),(421,83,'em_validation_q_tip','',NULL),(420,83,'em_validation_q','',NULL),(419,83,'random_group','',NULL),(418,83,'array_filter','',NULL),(417,83,'array_filter_exclude','',NULL),(416,83,'array_filter_style','0',NULL),(415,83,'other_comment_mandatory','0',NULL),(414,83,'other_numbers_only','0',NULL),(413,83,'printable_help','',NULL),(412,83,'cssclass','',NULL),(411,83,'hidden','0',NULL),(410,83,'other_replace_text','',NULL),(409,83,'display_columns','',NULL),(408,83,'hide_tip','1',NULL),(407,83,'random_order','0',NULL),(406,83,'alphasort','0',NULL),(405,83,'save_as_default','N',NULL),(404,83,'question_template','core',NULL),(84,6,'id','18',NULL),(85,6,'alphasort','0',NULL),(86,6,'array_filter_style','0',NULL),(87,6,'hidden','0',NULL),(88,6,'hide_tip','1',NULL),(89,6,'other_comment_mandatory','0',NULL),(90,6,'other_numbers_only','0',NULL),(91,6,'page_break','0',NULL),(92,6,'public_statistics','0',NULL),(93,6,'random_order','0',NULL),(94,6,'scale_export','0',NULL),(95,6,'statistics_graphtype','0',NULL),(96,6,'statistics_showgraph','1',NULL),(97,6,'time_limit_action','1',NULL),(98,6,'time_limit_disable_next','0',NULL),(99,6,'time_limit_disable_prev','0',NULL),(100,7,'id','19',NULL),(101,7,'alphasort','0',NULL),(102,7,'array_filter_style','0',NULL),(103,7,'hidden','0',NULL),(104,7,'hide_tip','1',NULL),(105,7,'other_comment_mandatory','1',NULL),(106,7,'other_numbers_only','0',NULL),(107,7,'other_replace_text','Otro (especifique)',NULL),(108,7,'page_break','0',NULL),(109,7,'public_statistics','0',NULL),(110,7,'random_order','0',NULL),(111,7,'scale_export','0',NULL),(112,7,'statistics_graphtype','0',NULL),(113,7,'statistics_showgraph','1',NULL),(114,7,'time_limit_action','1',NULL),(115,7,'time_limit_disable_next','0',NULL),(116,7,'time_limit_disable_prev','0',NULL),(117,8,'id','20',NULL),(118,8,'alphasort','0',NULL),(119,8,'array_filter_style','0',NULL),(120,8,'hidden','0',NULL),(121,8,'hide_tip','1',NULL),(122,8,'other_comment_mandatory','1',NULL),(123,8,'other_numbers_only','0',NULL),(124,8,'other_replace_text','Otro (especifique)',NULL),(125,8,'page_break','0',NULL),(126,8,'public_statistics','0',NULL),(127,8,'random_order','0',NULL),(128,8,'scale_export','0',NULL),(129,8,'statistics_graphtype','0',NULL),(130,8,'statistics_showgraph','1',NULL),(131,8,'time_limit_action','1',NULL),(132,8,'time_limit_disable_next','0',NULL),(133,8,'time_limit_disable_prev','0',NULL),(134,9,'id','21',NULL),(135,9,'alphasort','0',NULL),(136,9,'array_filter_style','0',NULL),(137,9,'hidden','0',NULL),(138,9,'hide_tip','1',NULL),(139,9,'other_comment_mandatory','1',NULL),(140,9,'other_numbers_only','0',NULL),(141,9,'other_replace_text','Otro (especifique)',NULL),(142,9,'page_break','0',NULL),(143,9,'public_statistics','0',NULL),(144,9,'random_order','0',NULL),(145,9,'scale_export','0',NULL),(146,9,'statistics_graphtype','0',NULL),(147,9,'statistics_showgraph','1',NULL),(148,9,'time_limit_action','1',NULL),(149,9,'time_limit_disable_next','0',NULL),(150,9,'time_limit_disable_prev','0',NULL),(151,10,'id','22',NULL),(152,10,'alphasort','0',NULL),(153,10,'array_filter_style','0',NULL),(154,10,'hidden','0',NULL),(155,10,'hide_tip','1',NULL),(156,10,'other_comment_mandatory','1',NULL),(157,10,'other_numbers_only','0',NULL),(158,10,'other_replace_text','Otro (especifique)',NULL),(159,10,'page_break','0',NULL),(160,10,'public_statistics','0',NULL),(161,10,'random_order','0',NULL),(162,10,'scale_export','0',NULL),(163,10,'statistics_graphtype','0',NULL),(164,10,'statistics_showgraph','1',NULL),(165,10,'time_limit_action','1',NULL),(166,10,'time_limit_disable_next','0',NULL),(167,10,'time_limit_disable_prev','0',NULL),(168,11,'id','23',NULL),(169,11,'alphasort','0',NULL),(170,11,'array_filter_style','0',NULL),(171,11,'hidden','0',NULL),(172,11,'hide_tip','1',NULL),(173,11,'other_comment_mandatory','1',NULL),(174,11,'other_numbers_only','0',NULL),(175,11,'other_replace_text','Otro (especifique)',NULL),(176,11,'page_break','0',NULL),(177,11,'public_statistics','0',NULL),(178,11,'random_order','0',NULL),(179,11,'scale_export','0',NULL),(180,11,'statistics_graphtype','0',NULL),(181,11,'statistics_showgraph','1',NULL),(182,11,'time_limit_action','1',NULL),(183,11,'time_limit_disable_next','0',NULL),(184,11,'time_limit_disable_prev','0',NULL),(185,12,'id','29',NULL),(186,12,'alphasort','0',NULL),(187,12,'array_filter_style','0',NULL),(188,12,'hidden','0',NULL),(189,12,'hide_tip','1',NULL),(190,12,'other_comment_mandatory','0',NULL),(191,12,'other_numbers_only','0',NULL),(192,12,'page_break','0',NULL),(193,12,'public_statistics','0',NULL),(194,12,'random_order','0',NULL),(195,12,'scale_export','0',NULL),(196,12,'statistics_graphtype','0',NULL),(197,12,'statistics_showgraph','1',NULL),(198,12,'time_limit_action','1',NULL),(199,12,'time_limit_disable_next','0',NULL),(200,12,'time_limit_disable_prev','0',NULL),(201,13,'id','30',NULL),(202,13,'alphasort','0',NULL),(203,13,'array_filter_style','0',NULL),(204,13,'hidden','0',NULL),(205,13,'hide_tip','1',NULL),(206,13,'other_comment_mandatory','0',NULL),(207,13,'other_numbers_only','0',NULL),(208,13,'page_break','0',NULL),(209,13,'public_statistics','0',NULL),(210,13,'random_order','0',NULL),(211,13,'scale_export','0',NULL),(212,13,'statistics_graphtype','0',NULL),(213,13,'statistics_showgraph','1',NULL),(214,13,'time_limit_action','1',NULL),(215,13,'time_limit_disable_next','0',NULL),(216,13,'time_limit_disable_prev','0',NULL),(217,14,'id','24',NULL),(218,14,'alphasort','0',NULL),(219,14,'array_filter_style','0',NULL),(220,14,'hidden','0',NULL),(221,14,'hide_tip','1',NULL),(222,14,'other_comment_mandatory','0',NULL),(223,14,'other_numbers_only','0',NULL),(224,14,'page_break','0',NULL),(225,14,'public_statistics','0',NULL),(226,14,'random_order','0',NULL),(227,14,'scale_export','0',NULL),(228,14,'statistics_graphtype','0',NULL),(229,14,'statistics_showgraph','1',NULL),(230,14,'time_limit_action','1',NULL),(231,14,'time_limit_disable_next','0',NULL),(232,14,'time_limit_disable_prev','0',NULL),(233,15,'id','6',NULL),(234,15,'alphasort','0',NULL),(235,15,'array_filter_style','0',NULL),(236,15,'hidden','0',NULL),(237,15,'hide_tip','1',NULL),(238,15,'other_comment_mandatory','1',NULL),(239,15,'other_numbers_only','0',NULL),(240,15,'other_replace_text','Especifique',NULL),(241,15,'page_break','0',NULL),(242,15,'public_statistics','0',NULL),(243,15,'random_order','0',NULL),(244,15,'scale_export','0',NULL),(245,15,'statistics_graphtype','0',NULL),(246,15,'statistics_showgraph','1',NULL),(247,15,'time_limit_action','1',NULL),(248,15,'time_limit_disable_next','0',NULL),(249,15,'time_limit_disable_prev','0',NULL),(250,16,'id','7',NULL),(251,16,'alphasort','0',NULL),(252,16,'array_filter_style','0',NULL),(253,16,'hidden','0',NULL),(254,16,'hide_tip','1',NULL),(255,16,'other_comment_mandatory','1',NULL),(256,16,'other_numbers_only','0',NULL),(257,16,'other_replace_text','Especifique',NULL),(258,16,'page_break','0',NULL),(259,16,'public_statistics','0',NULL),(260,16,'random_order','0',NULL),(261,16,'scale_export','0',NULL),(262,16,'statistics_graphtype','0',NULL),(263,16,'statistics_showgraph','1',NULL),(264,16,'time_limit_action','1',NULL),(265,16,'time_limit_disable_next','0',NULL),(266,16,'time_limit_disable_prev','0',NULL),(267,17,'id','25',NULL),(268,17,'alphasort','0',NULL),(269,17,'array_filter_style','0',NULL),(270,17,'hidden','0',NULL),(271,17,'hide_tip','1',NULL),(272,17,'other_comment_mandatory','0',NULL),(273,17,'other_numbers_only','0',NULL),(274,17,'page_break','0',NULL),(275,17,'public_statistics','0',NULL),(276,17,'random_order','0',NULL),(277,17,'scale_export','0',NULL),(278,17,'statistics_graphtype','0',NULL),(279,17,'statistics_showgraph','1',NULL),(280,17,'time_limit_action','1',NULL),(281,17,'time_limit_disable_next','0',NULL),(282,17,'time_limit_disable_prev','0',NULL),(283,18,'id','26',NULL),(284,18,'alphasort','0',NULL),(285,18,'array_filter_style','0',NULL),(286,18,'hidden','0',NULL),(287,18,'hide_tip','1',NULL),(288,18,'other_comment_mandatory','0',NULL),(289,18,'other_numbers_only','0',NULL),(290,18,'page_break','0',NULL),(291,18,'public_statistics','0',NULL),(292,18,'random_order','0',NULL),(293,18,'scale_export','0',NULL),(294,18,'statistics_graphtype','0',NULL),(295,18,'statistics_showgraph','1',NULL),(296,18,'time_limit_action','1',NULL),(297,18,'time_limit_disable_next','0',NULL),(298,18,'time_limit_disable_prev','0',NULL),(299,19,'id','27',NULL),(300,19,'alphasort','0',NULL),(301,19,'array_filter_style','0',NULL),(302,19,'hidden','0',NULL),(303,19,'hide_tip','1',NULL),(304,19,'other_comment_mandatory','0',NULL),(305,19,'other_numbers_only','0',NULL),(306,19,'page_break','0',NULL),(307,19,'public_statistics','0',NULL),(308,19,'random_order','0',NULL),(309,19,'scale_export','0',NULL),(310,19,'statistics_graphtype','0',NULL),(311,19,'statistics_showgraph','1',NULL),(312,19,'time_limit_action','1',NULL),(313,19,'time_limit_disable_next','0',NULL),(314,19,'time_limit_disable_prev','0',NULL),(315,20,'id','3',NULL),(316,20,'alphasort','0',NULL),(317,20,'array_filter_style','0',NULL),(318,20,'hidden','0',NULL),(319,20,'hide_tip','1',NULL),(320,20,'other_comment_mandatory','1',NULL),(321,20,'other_numbers_only','0',NULL),(322,20,'other_replace_text','Otro (especifique)',NULL),(323,20,'page_break','0',NULL),(324,20,'public_statistics','0',NULL),(325,20,'random_order','0',NULL),(326,20,'scale_export','0',NULL),(327,20,'statistics_graphtype','0',NULL),(328,20,'statistics_showgraph','1',NULL),(329,20,'time_limit_action','1',NULL),(330,20,'time_limit_disable_next','0',NULL),(331,20,'time_limit_disable_prev','0',NULL),(332,21,'id','28',NULL),(333,21,'hidden','0',NULL),(334,21,'hide_tip','0',NULL),(335,21,'input_size','33',NULL),(336,21,'max_num_value_n','365',NULL),(337,21,'maximum_chars','3',NULL),(338,21,'min_num_value_n','1',NULL),(339,21,'num_value_int_only','1',NULL),(340,21,'page_break','0',NULL),(341,21,'public_statistics','0',NULL),(342,21,'statistics_graphtype','0',NULL),(343,21,'statistics_showgraph','1',NULL),(344,22,'id','8',NULL),(345,22,'array_filter_style','0',NULL),(346,22,'hidden','0',NULL),(347,22,'hide_tip','1',NULL),(348,22,'page_break','0',NULL),(349,22,'public_statistics','0',NULL),(350,22,'random_order','0',NULL),(351,22,'repeat_headings','10',NULL),(352,22,'scale_export','0',NULL),(353,22,'statistics_graphtype','0',NULL),(354,22,'statistics_showgraph','1',NULL),(355,22,'use_dropdown','0',NULL),(356,23,'id','457',NULL),(357,23,'array_filter_style','0',NULL),(358,23,'hidden','0',NULL),(359,23,'hide_tip','1',NULL),(360,23,'page_break','0',NULL),(361,23,'public_statistics','0',NULL),(362,23,'random_order','0',NULL),(363,23,'repeat_headings','10',NULL),(364,23,'scale_export','0',NULL),(365,23,'statistics_graphtype','0',NULL),(366,23,'statistics_showgraph','1',NULL),(367,23,'use_dropdown','0',NULL),(368,24,'id','485',NULL),(369,24,'array_filter_style','0',NULL),(370,24,'hidden','0',NULL),(371,24,'hide_tip','1',NULL),(372,24,'page_break','0',NULL),(373,24,'public_statistics','0',NULL),(374,24,'random_order','0',NULL),(375,24,'repeat_headings','10',NULL),(376,24,'scale_export','0',NULL),(377,24,'statistics_graphtype','0',NULL),(378,24,'statistics_showgraph','1',NULL),(379,24,'use_dropdown','0',NULL),(380,25,'id','520',NULL),(381,25,'array_filter_style','0',NULL),(382,25,'hidden','0',NULL),(383,25,'hide_tip','1',NULL),(384,25,'page_break','0',NULL),(385,25,'public_statistics','0',NULL),(386,25,'random_order','0',NULL),(387,25,'repeat_headings','10',NULL),(388,25,'scale_export','0',NULL),(389,25,'statistics_graphtype','0',NULL),(390,25,'statistics_showgraph','1',NULL),(391,25,'use_dropdown','0',NULL),(392,26,'id','563',NULL),(393,26,'array_filter_style','0',NULL),(394,26,'hidden','0',NULL),(395,26,'hide_tip','1',NULL),(396,26,'page_break','0',NULL),(397,26,'public_statistics','0',NULL),(398,26,'random_order','0',NULL),(399,26,'repeat_headings','10',NULL),(400,26,'scale_export','0',NULL),(401,26,'statistics_graphtype','0',NULL),(402,26,'statistics_showgraph','1',NULL),(403,26,'use_dropdown','0',NULL),(434,83,'time_limit_message','',NULL),(435,83,'time_limit_message_style','',NULL),(436,83,'time_limit_warning','',NULL),(437,83,'time_limit_warning_display_time','',NULL),(438,83,'time_limit_warning_message','',NULL),(439,83,'time_limit_warning_style','',NULL),(440,83,'time_limit_warning_2','',NULL),(441,83,'time_limit_warning_2_display_time','',NULL),(442,83,'time_limit_warning_2_message','',NULL),(443,83,'time_limit_warning_2_style','',NULL),(444,83,'clear_default','',NULL);
/*!40000 ALTER TABLE `lsud_question_attributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_question_l10ns`
--

DROP TABLE IF EXISTS `lsud_question_l10ns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_question_l10ns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `qid` int(11) NOT NULL,
  `question` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `help` text COLLATE utf8mb4_unicode_ci,
  `script` text COLLATE utf8mb4_unicode_ci,
  `language` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lsud_idx1_question_ls` (`qid`,`language`)
) ENGINE=MyISAM AUTO_INCREMENT=84 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_question_l10ns`
--

LOCK TABLES `lsud_question_l10ns` WRITE;
/*!40000 ALTER TABLE `lsud_question_l10ns` DISABLE KEYS */;
INSERT INTO `lsud_question_l10ns` (`id`, `qid`, `question`, `help`, `script`, `language`) VALUES (1,1,'<p>Edad en años</p>','',NULL,'es'),(3,3,'<p>Etnia (autoidentificación étnica)</p>','',NULL,'es'),(4,4,'<p>Provincia donde trabaja</p>','',NULL,'es'),(83,83,'<p>Género</p>','','','es'),(6,6,'<p>Estado civil</p>','',NULL,'es'),(7,7,'<p>Tipo de trabajador</p>','',NULL,'es'),(8,8,'<p>Tipo de institución</p>','',NULL,'es'),(9,9,'<p>Institución a la que pertenece</p>','',NULL,'es'),(10,10,'<p>Tipo de servicio donde trabaja</p>','',NULL,'es'),(11,11,'<p>Último título alcanzado</p>','',NULL,'es'),(12,12,'<p>Recibió entrenamiento específico para enfrentar la pandemia en los últimos 6 meses</p>','',NULL,'es'),(13,13,'<p>Conocimiento sobre existencia de manuales y protocolos para controlar la pandemia que el Ministerio de Salud y las autoridades pertinentes desarrollaron</p>','',NULL,'es'),(14,14,'<p>Dispone de todos los implementos de protección</p>','',NULL,'es'),(15,15,'<p>Diagnóstico clínico de COVID-19</p>','',NULL,'es'),(16,16,'<p>En caso positivo, se realizó PCR</p>','',NULL,'es'),(17,17,'<p>Resultado PCR</p>','',NULL,'es'),(18,18,'<p>Se realizó pruebas cortas</p>','',NULL,'es'),(19,19,'<p>Ingreso en hospitalario</p>','',NULL,'es'),(20,20,'<p>Sala a la cual ingresó</p>','',NULL,'es'),(21,21,'<p>Número de días de ingreso</p>','',NULL,'es'),(22,22,'<p>Responda las siguientes preguntas</p>','',NULL,'es'),(23,23,'<p>Responda las siguientes preguntas</p>','',NULL,'es'),(24,24,'<p>Responda las siguientes preguntas</p>','',NULL,'es'),(25,25,'<p>Responda las siguientes preguntas</p>','',NULL,'es'),(26,26,'<p>Responda las siguientes preguntas</p>','',NULL,'es'),(27,27,'Los principales síntomas clínicos de COVID-19 son fiebre, fatiga, tos seca y mialgia.','',NULL,'es'),(28,28,'A diferencia del resfriado común, la nariz tapada, la secreción nasal y los estornudos son menos comunes en personas infectadas con el virus COVID-19','',NULL,'es'),(29,29,'El periodo de incubación es de 2 a 14 días','',NULL,'es'),(30,30,'Actualmente no existe una cura efectiva para COVID-19, pero el tratamiento sintomático y de apoyo temprano puede ayudar a la mayoría de los pacientes a recuperarse de la infección','',NULL,'es'),(31,31,'No todas las personas con COVID-19 desarrollarán casos graves. Solo aquellos que son ancianos, tienen enfermedades crónicas y son obesos tienen más probabilidades de ser casos graves.','',NULL,'es'),(32,32,'Comer o contactar animales salvajes provocaría la infección por el virus COVID-19','',NULL,'es'),(33,33,'Las personas con COVID-19 no pueden infectar el virus a otras mientras no haya fiebre presente','',NULL,'es'),(34,34,'El virus COVID-19 se propaga a través de gotitas respiratorias de individuos infectados.','',NULL,'es'),(35,35,'Los residentes comunes pueden usar máscaras médicas generales para prevenir la infección por el virus COVID-19','',NULL,'es'),(36,36,'No es necesario que los niños y adultos jóvenes tomen medidas para prevenir la infección por el virus COVID-19.','',NULL,'es'),(37,37,'Para prevenir la infección por COVID-19, las personas deben evitar ir a lugares con mucha gente como estaciones de tren y evitar el transporte público','',NULL,'es'),(38,38,'El aislamiento y el tratamiento de personas infectadas con el virus COVID-19 son formas efectivas de reducir la propagación del virus.','',NULL,'es'),(39,39,'Las personas que tienen contacto con alguien infectado con el virus COVID-19 deben aislarse inmediatamente en un lugar adecuado. En general, el período de observación es de 14 días.','',NULL,'es'),(40,40,'Se cree que los síntomas del nuevo COVID-19 pueden aparecer en tan solo 2 días o hasta 14 después de la exposición.','',NULL,'es'),(41,41,'Si alguien contrae COVID-19, no hay posibilidad de supervivencia.','',NULL,'es'),(42,42,'Si alguien recibió una vacuna contra la gripe, una vacuna contra el COVID-19 es suficiente','',NULL,'es'),(43,43,'Incluso en áreas que experimentan brotes, los productos cárnicos se pueden consumir de manera segura si estos se cocinan a fondo y se manejan adecuadamente durante la preparación de los alimentos.','',NULL,'es'),(44,44,'Si alguien trabaja en un \"mercado húmedo\", se recomienda desinfectar el equipo y el área de trabajo al menos una vez al día.  ','',NULL,'es'),(45,45,'Según las pautas de la OMS para el nuevo coronavirus, solo necesita lavarse las manos cuando estén visiblemente sucias.','',NULL,'es'),(46,46,'Existen actualmente tratamientos específicos para la enfermedad','',NULL,'es'),(47,47,'¿Está de acuerdo en que el COVID-19 finalmente se controlará con éxito?','',NULL,'es'),(48,48,'¿Confía en que Ecuador pueda ganar la batalla contra el virus COVID-19','',NULL,'es'),(49,49,'Si descubro que contacté a una persona infectada con el virus, informaré a las autoridades sanitaria','',NULL,'es'),(50,50,'Si descubrí que contacté a una persona infectada con el virus, acepto aislarme en un hospital de aislamiento durante un cierto período de tiempo hasta que se demuestre que estoy libre de la enfermedad','',NULL,'es'),(51,51,'Si se me solicita que me aísle por un cierto período de tiempo, creo que mi salario continuará durante este período','',NULL,'es'),(52,52,'Si hay una vacuna disponible para el virus, estoy dispuesto a recomendarla','',NULL,'es'),(53,53,'Normalmente sigo las actualizaciones sobre la propagación del virus en el país','',NULL,'es'),(54,54,'Si hay medidas y equipos de protección disponibles a un precio asequible, los compraría?','',NULL,'es'),(55,55,'En los últimos días, ¿ha ido a algún lugar con aglomeración de personas?','',NULL,'es'),(56,56,'En los últimos días, ¿se puesto una mascarilla al salir de casa?','',NULL,'es'),(57,57,'He cancelado o pospuesto reuniones con amigos, comidas y eventos deportivos','',NULL,'es'),(58,58,'Reducción en el uso del transporte público','',NULL,'es'),(59,59,'Fui de compras con menos frecuencia','',NULL,'es'),(60,60,'Reducción del uso de espacios cerrados, como la biblioteca, los teatros y el cine','',NULL,'es'),(61,61,'Evité toser alrededor de las personas tanto como sea posible','',NULL,'es'),(62,62,'Evité los lugares donde se reúne una gran cantidad de personas','',NULL,'es'),(63,63,'Aumenté la frecuencia de limpieza y desinfección de artículos que pueden ser fácilmente infectados','',NULL,'es'),(64,64,'Me lavé las manos con más frecuencia de lo habitual','',NULL,'es'),(65,65,'Discutí la prevención de COVID-19 con mi familia y amigos','',NULL,'es'),(66,66,'No me gusta usar mascarilla porque es antiestética','',NULL,'es'),(67,67,'Quiero que se tome la temperatura de las personas antes de que entren en lugares públicos','',NULL,'es'),(68,68,'Utiliza contenedores para la disposición de residuos (Tapa y pedal)','',NULL,'es'),(69,69,'Me auto aislaría en casa si fuera necesario','',NULL,'es'),(70,70,'Es extremadamente peligroso si el virus se extiende a la comunidad','',NULL,'es'),(71,71,'La falta de información sobre el Coronavirus hace que sea difícil prepararse para cada escenario','',NULL,'es'),(72,72,'La tasa de recuperación de la enfermedad es alta, lo cual es bueno','',NULL,'es'),(73,73,'Me preocupa enfermarme al tratar con el público','',NULL,'es'),(74,74,'Me enfermaré probablemente con coronavirus/COVID-19','',NULL,'es'),(75,75,'Me preocupa contraer una infección mientras trabajo en entornos de atención médica','',NULL,'es'),(76,76,'Siento que la enfermedad será muy peligrosa para aquellos que tienen más probabilidades de desarrollarla y será leve para el resto','',NULL,'es'),(77,77,'Todos los pacientes con coronavirus necesitarán atención médica de apoyo','',NULL,'es'),(78,78,'La infección con el virus está asociada con el estigma (por ejemplo: las personas infectadas se sienten avergonzadas porque las personas tienen miedo y las evitan)','',NULL,'es'),(79,79,'Creo que la cobertura mediática sobre esta enfermedad es exagerada','',NULL,'es'),(80,80,'Creo que este virus fue inicialmente diseñado como un arma biológica','',NULL,'es'),(81,81,'¿Cuánto cree que Ud. comprende la estrategia del gobierno para hacer frente a la pandemia?','',NULL,'es'),(82,82,'¿Cuánto cree que Ud. comprende la estrategia del gobierno para hacer frente a la pandemia?','',NULL,'es');
/*!40000 ALTER TABLE `lsud_question_l10ns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_question_themes`
--

DROP TABLE IF EXISTS `lsud_question_themes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_question_themes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `visible` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `xml_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation_date` datetime DEFAULT NULL,
  `author` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `author_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `author_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `copyright` text COLLATE utf8mb4_unicode_ci,
  `license` text COLLATE utf8mb4_unicode_ci,
  `version` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `api_version` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `last_update` datetime DEFAULT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `theme_type` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `question_type` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `core_theme` tinyint(1) DEFAULT NULL,
  `extends` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `group` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `settings` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `lsud_idx1_question_themes` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_question_themes`
--

LOCK TABLES `lsud_question_themes` WRITE;
/*!40000 ALTER TABLE `lsud_question_themes` DISABLE KEYS */;
INSERT INTO `lsud_question_themes` (`id`, `name`, `visible`, `xml_path`, `image_path`, `title`, `creation_date`, `author`, `author_email`, `author_url`, `copyright`, `license`, `version`, `api_version`, `description`, `last_update`, `owner_id`, `theme_type`, `question_type`, `core_theme`, `extends`, `group`, `settings`) VALUES (1,'5pointchoice','Y','application/views/survey/questions/answer/5pointchoice','/assets/images/screenshots/5.png','5 Point Choice','2018-09-08 00:00:00','Dominik Vitt','dominik.vitt@limesurvey.org','http://www.limesurvey.org','Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.','GNU General Public License version 2 or later','1.0','1','5 point choice question type configuration','2019-09-23 15:05:59',1,'question_theme','5',1,'','Single choice questions','{\"subquestions\":\"0\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"0\",\"assessable\":\"0\",\"class\":\"choice-5-pt-radio\"}'),(2,'arrays/10point','Y','application/views/survey/questions/answer/arrays/10point','/assets/images/screenshots/B.png','Array (10 Point Choice)','2018-09-08 00:00:00','Dominik Vitt','dominik.vitt@limesurvey.org','http://www.limesurvey.org','Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.','GNU General Public License version 2 or later','1.0','1','Array (10 point choice) question type configuration','2019-09-23 15:05:59',1,'question_theme','B',1,'','Arrays','{\"subquestions\":\"1\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"0\",\"assessable\":\"1\",\"class\":\"array-10-pt\"}'),(3,'arrays/5point','Y','application/views/survey/questions/answer/arrays/5point','/assets/images/screenshots/A.png','Array (5 Point Choice)','2018-09-08 00:00:00','Dominik Vitt','dominik.vitt@limesurvey.org','http://www.limesurvey.org','Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.','GNU General Public License version 2 or later','1.0','1','Array (5 point choice) question type configuration','2019-09-23 15:05:59',1,'question_theme','A',1,'','Arrays','{\"subquestions\":\"1\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"0\",\"assessable\":\"1\",\"class\":\"array-5-pt\"}'),(4,'arrays/array','Y','application/views/survey/questions/answer/arrays/array','/assets/images/screenshots/F.png','Array','2018-09-08 00:00:00','Dominik Vitt','dominik.vitt@limesurvey.org','http://www.limesurvey.org','Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.','GNU General Public License version 2 or later','1.0','1','Array question type configuration','2019-09-23 15:05:59',1,'question_theme','F',1,'','Arrays','{\"subquestions\":\"1\",\"answerscales\":\"1\",\"hasdefaultvalues\":\"0\",\"assessable\":\"1\",\"class\":\"array-flexible-row\"}'),(5,'arrays/column','Y','application/views/survey/questions/answer/arrays/column','/assets/images/screenshots/H.png','Array by column','2018-09-08 00:00:00','Dominik Vitt','dominik.vitt@limesurvey.org','http://www.limesurvey.org','Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.','GNU General Public License version 2 or later','1.0','1','Array by column question type configuration','2019-09-23 15:05:59',1,'question_theme','H',1,'','Arrays','{\"subquestions\":\"1\",\"answerscales\":\"1\",\"hasdefaultvalues\":\"0\",\"assessable\":\"1\",\"class\":\"array-flexible-column\"}'),(6,'arrays/dualscale','Y','application/views/survey/questions/answer/arrays/dualscale','/assets/images/screenshots/1.png','Array dual scale','2018-09-08 00:00:00','Dominik Vitt','dominik.vitt@limesurvey.org','http://www.limesurvey.org','Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.','GNU General Public License version 2 or later','1.0','1','Array dual scale question type configuration','2019-09-23 15:05:59',1,'question_theme','1',1,'','Arrays','{\"subquestions\":\"1\",\"answerscales\":\"2\",\"hasdefaultvalues\":\"0\",\"assessable\":\"1\",\"class\":\"array-flexible-duel-scale\"}'),(7,'arrays/increasesamedecrease','Y','application/views/survey/questions/answer/arrays/increasesamedecrease','/assets/images/screenshots/E.png','Array (Increase/Same/Decrease)','2018-09-08 00:00:00','Dominik Vitt','dominik.vitt@limesurvey.org','http://www.limesurvey.org','Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.','GNU General Public License version 2 or later','1.0','1','Array (Increase/Same/Decrease) question type configuration','2019-09-23 15:05:59',1,'question_theme','E',1,'','Arrays','{\"subquestions\":\"1\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"0\",\"assessable\":\"1\",\"class\":\"array-increase-same-decrease\"}'),(8,'arrays/multiflexi','Y','application/views/survey/questions/answer/arrays/multiflexi','/assets/images/screenshots/COLON.png','Array (Numbers)','2018-09-08 00:00:00','Dominik Vitt','dominik.vitt@limesurvey.org','http://www.limesurvey.org','Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.','GNU General Public License version 2 or later','1.0','1','Array (Numbers) question type configuration','2019-09-23 15:05:59',1,'question_theme',':',1,'','Arrays','{\"subquestions\":\"2\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"0\",\"assessable\":\"1\",\"class\":\"array-multi-flexi\"}'),(9,'arrays/texts','Y','application/views/survey/questions/answer/arrays/texts','/assets/images/screenshots/;.png','Array (Texts)','2018-09-08 00:00:00','Dominik Vitt','dominik.vitt@limesurvey.org','http://www.limesurvey.org','Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.','GNU General Public License version 2 or later','1.0','1','Array (Texts) question type configuration','2019-09-23 15:05:59',1,'question_theme',';',1,'','Arrays','{\"subquestions\":\"2\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"0\",\"assessable\":\"0\",\"class\":\"array-multi-flexi-text\"}'),(10,'arrays/yesnouncertain','Y','application/views/survey/questions/answer/arrays/yesnouncertain','/assets/images/screenshots/C.png','Array (Yes/No/Uncertain)','2018-09-08 00:00:00','Dominik Vitt','dominik.vitt@limesurvey.org','http://www.limesurvey.org','Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.','GNU General Public License version 2 or later','1.0','1','Array (Yes/No/Uncertain) question type configuration','2019-09-23 15:05:59',1,'question_theme','C',1,'','Arrays','{\"subquestions\":\"1\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"0\",\"assessable\":\"1\",\"class\":\"array-yes-uncertain-no\"}'),(11,'boilerplate','Y','application/views/survey/questions/answer/boilerplate','/assets/images/screenshots/X.png','Text display','2018-09-08 00:00:00','Dominik Vitt','dominik.vitt@limesurvey.org','http://www.limesurvey.org','Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.','GNU General Public License version 2 or later','1.0','1','Text display question type configuration','2019-09-23 15:05:59',1,'question_theme','X',1,'','Mask questions','{\"subquestions\":\"0\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"0\",\"assessable\":\"0\",\"class\":\"boilerplate\"}'),(12,'date','Y','application/views/survey/questions/answer/date','/assets/images/screenshots/D.png','Date/Time','2018-09-08 00:00:00','Dominik Vitt','dominik.vitt@limesurvey.org','http://www.limesurvey.org','Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.','GNU General Public License version 2 or later','1.0','1','Date/Time question type configuration','2019-09-23 15:05:59',1,'question_theme','D',1,'','Mask questions','{\"subquestions\":\"0\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"1\",\"assessable\":\"0\",\"class\":\"date\"}'),(13,'equation','Y','application/views/survey/questions/answer/equation','/assets/images/screenshots/EQUATION.png','Equation','2018-09-08 00:00:00','Dominik Vitt','dominik.vitt@limesurvey.org','http://www.limesurvey.org','Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.','GNU General Public License version 2 or later','1.0','1','Equation question type configuration','2019-09-23 15:05:59',1,'question_theme','*',1,'','Mask questions','{\"subquestions\":\"0\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"0\",\"assessable\":\"0\",\"class\":\"equation\"}'),(14,'file_upload','Y','application/views/survey/questions/answer/file_upload','/assets/images/screenshots/PIPE.png','File upload','2018-09-08 00:00:00','Dominik Vitt','dominik.vitt@limesurvey.org','http://www.limesurvey.org','Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.','GNU General Public License version 2 or later','1.0','1','File upload question type configuration','2019-09-23 15:05:59',1,'question_theme','|',1,'','Mask questions','{\"subquestions\":\"0\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"0\",\"assessable\":\"0\",\"class\":\"upload-files\"}'),(15,'gender','Y','application/views/survey/questions/answer/gender','/assets/images/screenshots/G.png','Gender','2018-09-08 00:00:00','Dominik Vitt','dominik.vitt@limesurvey.org','http://www.limesurvey.org','Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.','GNU General Public License version 2 or later','1.0','1','Gender question type configuration','2019-09-23 15:05:59',1,'question_theme','G',1,'','Mask questions','{\"subquestions\":\"0\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"0\",\"assessable\":\"0\",\"class\":\"gender\"}'),(16,'hugefreetext','Y','application/views/survey/questions/answer/hugefreetext','/assets/images/screenshots/U.png','Huge Free Text','1970-01-01 01:00:00','Patrick Teichmann','patrick.teichmann@limesurvey.org','http://www.limesurvey.org','Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.','GNU General Public License version 2 or later','1.0','1','Huge free text question type configuration','2019-09-23 15:05:59',1,'question_theme','U',1,'','Text questions','{\"subquestions\":\"0\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"1\",\"assessable\":\"0\",\"class\":\"text-huge\"}'),(17,'language','Y','application/views/survey/questions/answer/language','/assets/images/screenshots/I.png','Language switch','2018-09-08 00:00:00','Dominik Vitt','dominik.vitt@limesurvey.org','http://www.limesurvey.org','Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.','GNU General Public License version 2 or later','1.0','1','Language switch question type configuration','2019-09-23 15:05:59',1,'question_theme','I',1,'','Mask questions','{\"subquestions\":\"0\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"0\",\"assessable\":\"0\",\"class\":\"language\"}'),(18,'listradio','Y','application/views/survey/questions/answer/listradio','/assets/images/screenshots/L.png','List (Radio)','2018-09-08 00:00:00','Dominik Vitt','dominik.vitt@limesurvey.org','http://www.limesurvey.org','Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.','GNU General Public License version 2 or later','1.0','1','List (radio) question type configuration','2019-09-23 15:05:59',1,'question_theme','L',1,'','Single choice questions','{\"subquestions\":\"0\",\"answerscales\":\"1\",\"hasdefaultvalues\":\"1\",\"assessable\":\"1\",\"class\":\"list-radio\"}'),(19,'list_dropdown','Y','application/views/survey/questions/answer/list_dropdown','/assets/images/screenshots/!.png','List (Dropdown)','2018-09-08 00:00:00','Dominik Vitt','dominik.vitt@limesurvey.org','http://www.limesurvey.org','Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.','GNU General Public License version 2 or later','1.0','1','List (dropdown) question type configuration','2019-09-23 15:05:59',1,'question_theme','!',1,'','Single choice questions','{\"subquestions\":\"0\",\"answerscales\":\"1\",\"hasdefaultvalues\":\"1\",\"assessable\":\"1\",\"class\":\"list-dropdown\"}'),(20,'list_with_comment','Y','application/views/survey/questions/answer/list_with_comment','/assets/images/screenshots/O.png','List with comment','2018-09-08 00:00:00','Dominik Vitt','dominik.vitt@limesurvey.org','http://www.limesurvey.org','Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.','GNU General Public License version 2 or later','1.0','1','List with comment question type configuration','2019-09-23 15:05:59',1,'question_theme','O',1,'','Single choice questions','{\"subquestions\":\"0\",\"answerscales\":\"1\",\"hasdefaultvalues\":\"1\",\"assessable\":\"1\",\"class\":\"list-with-comment\"}'),(21,'longfreetext','Y','application/views/survey/questions/answer/longfreetext','/assets/images/screenshots/T.png','Long free text','2018-09-08 00:00:00','Dominik Vitt','dominik.vitt@limesurvey.org','http://www.limesurvey.org','Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.','GNU General Public License version 2 or later','1.0','1','Long free text question type configuration','2019-09-23 15:05:59',1,'question_theme','T',1,'','Text questions','{\"subquestions\":\"0\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"1\",\"assessable\":\"0\",\"class\":\"text-long\"}'),(22,'multiplechoice','Y','application/views/survey/questions/answer/multiplechoice','/assets/images/screenshots/M.png','Multiple choice','2018-09-08 00:00:00','Dominik Vitt','dominik.vitt@limesurvey.org','http://www.limesurvey.org','Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.','GNU General Public License version 2 or later','1.0','1','Multiple choice question type configuration','2019-09-23 15:05:59',1,'question_theme','M',1,'','Multiple choice questions','{\"subquestions\":\"1\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"1\",\"assessable\":\"1\",\"class\":\"multiple-opt\"}'),(23,'multiplechoice_with_comments','Y','application/views/survey/questions/answer/multiplechoice_with_comments','/assets/images/screenshots/P.png','Multiple choice with comments','2018-09-08 00:00:00','Dominik Vitt','dominik.vitt@limesurvey.org','http://www.limesurvey.org','Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.','GNU General Public License version 2 or later','1.0','1','Multiple choice with comments question type configuration','2019-09-23 15:05:59',1,'question_theme','P',1,'','Multiple choice questions','{\"subquestions\":\"1\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"1\",\"assessable\":\"1\",\"class\":\"multiple-opt-comments\"}'),(24,'multiplenumeric','Y','application/views/survey/questions/answer/multiplenumeric','/assets/images/screenshots/K.png','Multiple Numerical Input','2018-09-08 00:00:00','Dominik Vitt','dominik.vitt@limesurvey.org','http://www.limesurvey.org','Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.','GNU General Public License version 2 or later','1.0','1','Multiple numerical input question type configuration','2019-09-23 15:05:59',1,'question_theme','K',1,'','Mask questions','{\"subquestions\":\"1\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"1\",\"assessable\":\"1\",\"class\":\"numeric-multi\"}'),(25,'multipleshorttext','Y','application/views/survey/questions/answer/multipleshorttext','/assets/images/screenshots/Q.png','Multiple Short Text','2018-09-08 00:00:00','Dominik Vitt','dominik.vitt@limesurvey.org','http://www.limesurvey.org','Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.','GNU General Public License version 2 or later','1.0','1','Multiple short text question type configuration','2019-09-23 15:05:59',1,'question_theme','Q',1,'','Text questions','{\"subquestions\":\"1\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"1\",\"assessable\":\"0\",\"class\":\"multiple-short-txt\"}'),(26,'numerical','Y','application/views/survey/questions/answer/numerical','/assets/images/screenshots/N.png','Numerical Input','2018-09-08 00:00:00','Dominik Vitt','dominik.vitt@limesurvey.org','http://www.limesurvey.org','Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.','GNU General Public License version 2 or later','1.0','1','Numerical input question type configuration','2019-09-23 15:05:59',1,'question_theme','N',1,'','Mask questions','{\"subquestions\":\"0\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"1\",\"assessable\":\"0\",\"class\":\"numeric\"}'),(27,'ranking','Y','application/views/survey/questions/answer/ranking','/assets/images/screenshots/R.png','Ranking','2018-09-08 00:00:00','Dominik Vitt','dominik.vitt@limesurvey.org','http://www.limesurvey.org','Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.','GNU General Public License version 2 or later','1.0','1','Ranking question type configuration','2019-09-23 15:05:59',1,'question_theme','R',1,'','Mask questions','{\"subquestions\":\"0\",\"answerscales\":\"1\",\"hasdefaultvalues\":\"0\",\"assessable\":\"1\",\"class\":\"ranking\"}'),(28,'shortfreetext','Y','application/views/survey/questions/answer/shortfreetext','/assets/images/screenshots/S.png','Short Free Text','2018-09-08 00:00:00','Dominik Vitt','dominik.vitt@limesurvey.org','http://www.limesurvey.org','Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.','GNU General Public License version 2 or later','1.0','1','Short free text question type configuration','2019-09-23 15:05:59',1,'question_theme','S',1,'','Text questions','{\"subquestions\":\"0\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"1\",\"assessable\":\"0\",\"class\":\"text-short\"}'),(29,'yesno','Y','application/views/survey/questions/answer/yesno','/assets/images/screenshots/Y.png','Yes/No','2018-09-08 00:00:00','Dominik Vitt','dominik.vitt@limesurvey.org','http://www.limesurvey.org','Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.','GNU General Public License version 2 or later','1.0','1','Yes/No question type configuration','2019-09-23 15:05:59',1,'question_theme','Y',1,'','Mask questions','{\"subquestions\":\"0\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"1\",\"assessable\":\"0\",\"class\":\"yes-no\"}'),(30,'bootstrap_buttons','Y','themes/question/bootstrap_buttons/survey/questions/answer/listradio','/themes/question/bootstrap_buttons/survey/questions/answer/listradio/assets/bootstrap_buttons_listradio.png','Bootstrap buttons','1970-01-01 01:00:00','Dominik Vitt','dominik.vitt@limesurvey.org','http://www.limesurvey.org','Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.','GNU General Public License version 2 or later','1.0','1','New implementation of the Bootstrap buttons question theme','2019-09-23 15:05:59',1,'question_theme','L',1,'L','Single choice questions','{\"subquestions\":\"0\",\"answerscales\":\"1\",\"hasdefaultvalues\":\"1\",\"assessable\":\"1\",\"class\":\"list-radio\"}'),(31,'bootstrap_buttons','Y','themes/question/bootstrap_buttons/survey/questions/answer/multiplechoice','/themes/question/bootstrap_buttons/survey/questions/answer/multiplechoice/assets/bootstrap_buttons_multiplechoice.png','Bootstrap buttons','1970-01-01 01:00:00','Dominik Vitt','dominik.vitt@limesurvey.org','http://www.limesurvey.org','Copyright (C) 2005 - 2018 LimeSurvey Gmbh, Inc. All rights reserved.','GNU General Public License version 2 or later','1.0','1','New implementation of the Bootstrap buttons question theme','2019-09-23 15:05:59',1,'question_theme','M',1,'M','Multiple choice questions','{\"subquestions\":\"1\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"1\",\"assessable\":\"1\",\"class\":\"multiple-opt\"}'),(32,'browserdetect','Y','themes/question/browserdetect/survey/questions/answer/shortfreetext','/assets/images/screenshots/S.png','Browser detect','2017-07-09 00:00:00','Markus FlÃ¼r','mfluer@limesurvey.org','http://www.limesurvey.org','Copyright (C) 2005 - 2017 LimeSurvey Gmbh, Inc. All rights reserved.','GNU General Public License version 2 or later','1.0','1','Browser, Platform and Proxy detection','2019-09-23 15:05:59',1,'question_theme','S',1,'S','Text questions','{\"subquestions\":\"0\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"1\",\"assessable\":\"0\",\"class\":\"text-short\"}'),(33,'image_select-listradio','Y','themes/question/image_select/survey/questions/answer/listradio','/assets/images/screenshots/L.png','Image Select List (radio)','1970-01-01 01:00:00','Markus FlÃ¼r','mfluer@limesurvey.org','http://www.limesurvey.org','Copyright (C) 2005 - 2016 LimeSurvey Gmbh, Inc. All rights reserved.','GNU General Public License version 2 or later','1.0','1','List Radio with images.','2019-09-23 15:05:59',1,'question_theme','L',1,'L','Single choice questions','{\"subquestions\":\"0\",\"answerscales\":\"1\",\"hasdefaultvalues\":\"1\",\"assessable\":\"1\",\"class\":\"list-radio\"}'),(34,'image_select-multiplechoice','Y','themes/question/image_select/survey/questions/answer/multiplechoice','/assets/images/screenshots/M.png','Image Select Multiple choice','1970-01-01 01:00:00','Markus FlÃ¼r','mfluer@limesurvey.org','http://www.limesurvey.org','Copyright (C) 2005 - 2016 LimeSurvey Gmbh, Inc. All rights reserved.','GNU General Public License version 2 or later','1.0','1','Multiplechoice with images.','2019-09-23 15:05:59',1,'question_theme','M',1,'M','Multiple choice questions','{\"subquestions\":\"1\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"1\",\"assessable\":\"1\",\"class\":\"multiple-opt\"}'),(35,'inputondemand','Y','themes/question/inputondemand/survey/questions/answer/multipleshorttext','/assets/images/screenshots/Q.png','Input on demand','2019-10-04 00:00:00','Markus FlÃ¼r','mfluer@limesurvey.org','http://www.limesurvey.org','Copyright (C) 2005 - 2019 LimeSurvey Gmbh, Inc. All rights reserved.','GNU General Public License version 2 or later','1.0','1','Hide not needed input fields in multiple shorttext','2019-09-23 15:05:59',1,'question_theme','Q',1,'Q','Text questions','{\"subquestions\":\"1\",\"answerscales\":\"0\",\"hasdefaultvalues\":\"1\",\"assessable\":\"0\",\"class\":\"multiple-short-txt\"}'),(36,'ranking_advanced','Y','themes/question/ranking_advanced/survey/questions/answer/ranking','/assets/images/screenshots/R.png','Ranking Advanced','1970-01-01 01:00:00','Markus FlÃ¼r','mfluer@limesurvey.org','http://www.limesurvey.org','Copyright (C) 2005 - 2017 LimeSurvey Gmbh, Inc. All rights reserved.','GNU General Public License version 2 or later','1.0','1','New implementation of the ranking question','2019-09-23 15:05:59',1,'question_theme','R',1,'R','Mask questions','{\"subquestions\":\"0\",\"answerscales\":\"1\",\"hasdefaultvalues\":\"0\",\"assessable\":\"1\",\"class\":\"ranking\"}');
/*!40000 ALTER TABLE `lsud_question_themes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_questions`
--

DROP TABLE IF EXISTS `lsud_questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_questions` (
  `qid` int(11) NOT NULL AUTO_INCREMENT,
  `parent_qid` int(11) NOT NULL DEFAULT '0',
  `sid` int(11) NOT NULL DEFAULT '0',
  `gid` int(11) NOT NULL DEFAULT '0',
  `type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'T',
  `title` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `preg` text COLLATE utf8mb4_unicode_ci,
  `other` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `mandatory` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `encrypted` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT 'N',
  `question_order` int(11) NOT NULL,
  `scale_id` int(11) NOT NULL DEFAULT '0',
  `same_default` int(11) NOT NULL DEFAULT '0',
  `relevance` text COLLATE utf8mb4_unicode_ci,
  `modulename` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`qid`),
  KEY `lsud_idx1_questions` (`sid`),
  KEY `lsud_idx2_questions` (`gid`),
  KEY `lsud_idx3_questions` (`type`),
  KEY `lsud_idx4_questions` (`title`),
  KEY `lsud_idx5_questions` (`parent_qid`)
) ENGINE=MyISAM AUTO_INCREMENT=84 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_questions`
--

LOCK TABLES `lsud_questions` WRITE;
/*!40000 ALTER TABLE `lsud_questions` DISABLE KEYS */;
INSERT INTO `lsud_questions` (`qid`, `parent_qid`, `sid`, `gid`, `type`, `title`, `preg`, `other`, `mandatory`, `encrypted`, `question_order`, `scale_id`, `same_default`, `relevance`, `modulename`) VALUES (1,0,855621,1,'N','edad','','N','Y','N',1,0,1,'1',NULL),(3,0,855621,1,'L','etnia','','Y','Y','N',3,0,0,'1',NULL),(4,0,855621,1,'!','provincia','','N','Y','N',4,0,0,'1',NULL),(83,0,855621,1,'L','Genero','','N','Y','N',2,0,1,'1',''),(6,0,855621,1,'L','estadoCivil','','N','Y','N',5,0,1,'1',NULL),(7,0,855621,1,'L','tipoTrabajador','','Y','Y','N',6,0,0,'1',NULL),(8,0,855621,1,'L','tipoInstitucion','','Y','Y','N',7,0,1,'1',NULL),(9,0,855621,1,'L','institucion','','Y','Y','N',8,0,0,'1',NULL),(10,0,855621,1,'L','tipoServicio','','Y','Y','N',9,0,0,'1',NULL),(11,0,855621,1,'L','ultimoTitulo','','Y','Y','N',10,0,0,'1',NULL),(12,0,855621,1,'L','recibioEntrenamiento','','N','Y','N',11,0,1,'1',NULL),(13,0,855621,1,'L','conocimientoProtocol','','N','Y','N',12,0,0,'1',NULL),(14,0,855621,1,'L','implementosProteccio','','N','Y','N',13,0,1,'1',NULL),(15,0,855621,1,'L','diagnosticoCovid','','N','Y','N',14,0,0,'1',NULL),(16,0,855621,1,'L','pcr','','N','Y','N',15,0,1,'(((!is_empty(diagnosticoCovid.NAOK) && (diagnosticoCovid.NAOK == 1))))',NULL),(17,0,855621,1,'L','resultadoPcr','','N','Y','N',16,0,1,'(((!is_empty(diagnosticoCovid.NAOK) && (diagnosticoCovid.NAOK == 1))))',NULL),(18,0,855621,1,'L','pruebasCortas','','N','Y','N',17,0,1,'1',NULL),(19,0,855621,1,'L','ingresoHospitalario','','N','Y','N',18,0,0,'1',NULL),(20,0,855621,1,'L','salaIngreso','','Y','Y','N',19,0,1,'(((!is_empty(ingresoHospitalario.NAOK) && (ingresoHospitalario.NAOK == 1))))',NULL),(21,0,855621,1,'N','diasIngreso','','N','Y','N',20,0,1,'(((!is_empty(ingresoHospitalario.NAOK) && (ingresoHospitalario.NAOK == 1))))',NULL),(22,0,855621,2,'F','conocimientos','','N','Y','N',1,0,1,'1',NULL),(23,0,855621,3,'F','actitudes','','N','Y','N',1,0,1,'1',NULL),(24,0,855621,4,'F','practicas','','N','Y','N',1,0,0,'1',NULL),(25,0,855621,5,'F','riesgo','','N','Y','N',1,0,0,'1',NULL),(26,0,855621,5,'F','riesgoB','','N','S','N',2,0,0,'1',NULL),(27,22,855621,2,'F','1','','N','N','N',1,0,0,'1',NULL),(28,22,855621,2,'F','2','','N','N','N',2,0,0,'1',NULL),(29,22,855621,2,'F','3','','N','N','N',3,0,0,'1',NULL),(30,22,855621,2,'F','4','','N','N','N',4,0,0,'1',NULL),(31,22,855621,2,'F','5','','N','N','N',5,0,0,'1',NULL),(32,22,855621,2,'F','6','','N','N','N',6,0,0,'1',NULL),(33,22,855621,2,'F','7','','N','N','N',7,0,0,'1',NULL),(34,22,855621,2,'F','8','','N','N','N',8,0,0,'1',NULL),(35,22,855621,2,'F','9','','N','N','N',9,0,0,'1',NULL),(36,22,855621,2,'F','10','','N','N','N',10,0,0,'1',NULL),(37,22,855621,2,'F','11','','N','N','N',11,0,0,'1',NULL),(38,22,855621,2,'F','12','','N','N','N',12,0,0,'1',NULL),(39,22,855621,2,'F','13','','N','N','N',13,0,0,'1',NULL),(40,22,855621,2,'F','14','','N','N','N',14,0,0,'1',NULL),(41,22,855621,2,'F','15','','N','N','N',15,0,0,'1',NULL),(42,22,855621,2,'F','16','','N','N','N',16,0,0,'1',NULL),(43,22,855621,2,'F','17','','N','N','N',17,0,0,'1',NULL),(44,22,855621,2,'F','18','','N','N','N',18,0,0,'1',NULL),(45,22,855621,2,'F','19','','N','N','N',19,0,0,'1',NULL),(46,22,855621,2,'F','20','','N','N','N',20,0,0,'1',NULL),(47,23,855621,3,'F','1','','N','N','N',1,0,0,'1',NULL),(48,23,855621,3,'F','2','','N','N','N',2,0,0,'1',NULL),(49,23,855621,3,'F','3','','N','N','N',3,0,0,'1',NULL),(50,23,855621,3,'F','4','','N','N','N',4,0,0,'1',NULL),(51,23,855621,3,'F','5','','N','N','N',5,0,0,'1',NULL),(52,23,855621,3,'F','6','','N','N','N',6,0,0,'1',NULL),(53,23,855621,3,'F','7','','N','N','N',7,0,0,'1',NULL),(54,23,855621,3,'F','8','','N','N','N',8,0,0,'1',NULL),(55,24,855621,4,'F','1','','N','N','N',1,0,0,'1',NULL),(56,24,855621,4,'F','2','','N','N','N',2,0,0,'1',NULL),(57,24,855621,4,'F','3','','N','N','N',3,0,0,'1',NULL),(58,24,855621,4,'F','4','','N','N','N',4,0,0,'1',NULL),(59,24,855621,4,'F','5','','N','N','N',5,0,0,'1',NULL),(60,24,855621,4,'F','6','','N','N','N',6,0,0,'1',NULL),(61,24,855621,4,'F','7','','N','N','N',7,0,0,'1',NULL),(62,24,855621,4,'F','8','','N','N','N',8,0,0,'1',NULL),(63,24,855621,4,'F','9','','N','N','N',9,0,0,'1',NULL),(64,24,855621,4,'F','10','','N','N','N',10,0,0,'1',NULL),(65,24,855621,4,'F','11','','N','N','N',11,0,0,'1',NULL),(66,24,855621,4,'F','12','','N','N','N',12,0,0,'1',NULL),(67,24,855621,4,'F','13','','N','N','N',13,0,0,'1',NULL),(68,24,855621,4,'F','14','','N','N','N',14,0,0,'1',NULL),(69,24,855621,4,'F','15','','N','N','N',15,0,0,'1',NULL),(70,25,855621,5,'F','1','','N','N','N',1,0,0,'1',NULL),(71,25,855621,5,'F','2','','N','N','N',2,0,0,'1',NULL),(72,25,855621,5,'F','3','','N','N','N',3,0,0,'1',NULL),(73,25,855621,5,'F','4','','N','N','N',4,0,0,'1',NULL),(74,25,855621,5,'F','5','','N','N','N',5,0,0,'1',NULL),(75,25,855621,5,'F','6','','N','N','N',6,0,0,'1',NULL),(76,25,855621,5,'F','7','','N','N','N',7,0,0,'1',NULL),(77,25,855621,5,'F','8','','N','N','N',8,0,0,'1',NULL),(78,25,855621,5,'F','9','','N','N','N',9,0,0,'1',NULL),(79,25,855621,5,'F','10','','N','N','N',10,0,0,'1',NULL),(80,25,855621,5,'F','11','','N','N','N',11,0,0,'1',NULL),(81,25,855621,5,'F','12','','N','N','N',12,0,0,'1',NULL),(82,26,855621,5,'F','12','','N','N','N',14,0,0,'1',NULL);
/*!40000 ALTER TABLE `lsud_questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_quota`
--

DROP TABLE IF EXISTS `lsud_quota`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_quota` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qlimit` int(11) DEFAULT NULL,
  `action` int(11) DEFAULT NULL,
  `active` int(11) NOT NULL DEFAULT '1',
  `autoload_url` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `lsud_idx1_quota` (`sid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_quota`
--

LOCK TABLES `lsud_quota` WRITE;
/*!40000 ALTER TABLE `lsud_quota` DISABLE KEYS */;
/*!40000 ALTER TABLE `lsud_quota` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_quota_languagesettings`
--

DROP TABLE IF EXISTS `lsud_quota_languagesettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_quota_languagesettings` (
  `quotals_id` int(11) NOT NULL AUTO_INCREMENT,
  `quotals_quota_id` int(11) NOT NULL DEFAULT '0',
  `quotals_language` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en',
  `quotals_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quotals_message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `quotals_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quotals_urldescrip` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`quotals_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_quota_languagesettings`
--

LOCK TABLES `lsud_quota_languagesettings` WRITE;
/*!40000 ALTER TABLE `lsud_quota_languagesettings` DISABLE KEYS */;
/*!40000 ALTER TABLE `lsud_quota_languagesettings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_quota_members`
--

DROP TABLE IF EXISTS `lsud_quota_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_quota_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) DEFAULT NULL,
  `qid` int(11) DEFAULT NULL,
  `quota_id` int(11) DEFAULT NULL,
  `code` varchar(11) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lsud_idx1_quota_members` (`sid`,`qid`,`quota_id`,`code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_quota_members`
--

LOCK TABLES `lsud_quota_members` WRITE;
/*!40000 ALTER TABLE `lsud_quota_members` DISABLE KEYS */;
/*!40000 ALTER TABLE `lsud_quota_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_saved_control`
--

DROP TABLE IF EXISTS `lsud_saved_control`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_saved_control` (
  `scid` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) NOT NULL DEFAULT '0',
  `srid` int(11) NOT NULL DEFAULT '0',
  `identifier` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_code` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(192) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `saved_thisstep` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `saved_date` datetime NOT NULL,
  `refurl` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`scid`),
  KEY `lsud_idx1_saved_control` (`sid`),
  KEY `lsud_idx2_saved_control` (`srid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_saved_control`
--

LOCK TABLES `lsud_saved_control` WRITE;
/*!40000 ALTER TABLE `lsud_saved_control` DISABLE KEYS */;
/*!40000 ALTER TABLE `lsud_saved_control` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_sessions`
--

DROP TABLE IF EXISTS `lsud_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_sessions` (
  `id` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expire` int(11) DEFAULT NULL,
  `data` longblob,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_sessions`
--

LOCK TABLES `lsud_sessions` WRITE;
/*!40000 ALTER TABLE `lsud_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `lsud_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_settings_global`
--

DROP TABLE IF EXISTS `lsud_settings_global`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_settings_global` (
  `stg_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `stg_value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`stg_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_settings_global`
--

LOCK TABLES `lsud_settings_global` WRITE;
/*!40000 ALTER TABLE `lsud_settings_global` DISABLE KEYS */;
INSERT INTO `lsud_settings_global` (`stg_name`, `stg_value`) VALUES ('DBVersion','427'),('SessionName','zx91pbrjehynuh8ytm5ty85dzoo3ra89fhwstndnhetetxuz4krhpmi4ewr7majl'),('sitename','Encuestas UDLA'),('siteadminname','Administrador'),('siteadminemail','santiago.pesantez@integra-ec.com'),('siteadminbounce','santiago.pesantez@integra-ec.com'),('defaultlang','es'),('AssetsVersion','30159'),('last_survey_1','855621'),('last_question_sid_1','855621'),('last_question_gid_1','1'),('last_question_1_855621','83'),('last_question_1_855621_gid','1'),('last_question_1','83');
/*!40000 ALTER TABLE `lsud_settings_global` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_settings_user`
--

DROP TABLE IF EXISTS `lsud_settings_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_settings_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `entity` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_id` varchar(31) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stg_name` varchar(63) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stg_value` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `lsud_idx1_settings_user` (`uid`),
  KEY `lsud_idx2_settings_user` (`entity`),
  KEY `lsud_idx3_settings_user` (`entity_id`),
  KEY `lsud_idx4_settings_user` (`stg_name`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_settings_user`
--

LOCK TABLES `lsud_settings_user` WRITE;
/*!40000 ALTER TABLE `lsud_settings_user` DISABLE KEYS */;
INSERT INTO `lsud_settings_user` (`id`, `uid`, `entity`, `entity_id`, `stg_name`, `stg_value`) VALUES (1,1,NULL,NULL,'quickaction_state','1'),(2,1,NULL,NULL,'question_default_values_L','{ \"Display\":{ \"alphasort\":{ \"name\":\"alphasort\",\"title\":\"Sort answers alphabetically\",\"inputtype\":\"switch\",\"formElementId\":\"alphasort\",\"formElementName\":\"false\",\"formElementHelp\":\"Sort the answer options alphabetically\",\"formElementValue\":\"0\",\"aFormElementOptions\":{ \"name\":\"alphasort\",\"options\":{ \"option\":[{ \"value\":\"0\",\"text\":\"No\" },{ \"value\":\"1\",\"text\":\"Yes\" }] },\"category\":\"Display\",\"default\":\"0\",\"value\":\"\",\"sortorder\":\"100\",\"classes\":[\"form-control\"] } },\"random_order\":{ \"name\":\"random_order\",\"title\":\"Random order\",\"inputtype\":\"singleselect\",\"formElementId\":\"random_order\",\"formElementName\":\"false\",\"formElementHelp\":\"Present subquestions\\/answer options in random order\",\"formElementValue\":\"0\",\"aFormElementOptions\":{ \"name\":\"random_order\",\"options\":{ \"option\":[{ \"value\":\"0\",\"text\":\"No\" },{ \"value\":\"1\",\"text\":\"Yes\" }] },\"category\":\"Display\",\"default\":\"0\",\"value\":\"\",\"sortorder\":\"100\",\"classes\":[\"form-control\"] } },\"hide_tip\":{ \"name\":\"hide_tip\",\"title\":\"Hide tip\",\"inputtype\":\"switch\",\"formElementId\":\"hide_tip\",\"formElementName\":\"false\",\"formElementHelp\":\"Hide the tip that is normally shown with a question\",\"formElementValue\":\"1\",\"aFormElementOptions\":{ \"name\":\"hide_tip\",\"options\":{ \"option\":[{ \"value\":\"0\",\"text\":\"No\" },{ \"value\":\"1\",\"text\":\"Yes\" }] },\"category\":\"Display\",\"default\":\"0\",\"value\":\"\",\"sortorder\":\"100\",\"classes\":[\"form-control\"] } },\"display_columns\":{ \"name\":\"display_columns\",\"title\":\"Display columns\",\"inputtype\":\"columns\",\"formElementId\":\"display_columns\",\"formElementName\":\"false\",\"formElementHelp\":\"The answer options will be distributed across the number of columns set here\",\"formElementValue\":\"\",\"aFormElementOptions\":{ \"name\":\"display_columns\",\"options\":\"\",\"category\":\"Display\",\"value\":\"\",\"sortorder\":\"100\",\"classes\":[\"form-control\"] } },\"other_replace_text\":{ \"name\":\"other_replace_text\",\"title\":\"Label for \'Other:\' option\",\"inputtype\":\"text\",\"formElementId\":\"other_replace_text\",\"formElementName\":\"false\",\"formElementHelp\":\"Replaces the label of the &#039;Other:&#039; answer option with a custom text\",\"formElementValue\":\"\",\"aFormElementOptions\":{ \"name\":\"other_replace_text\",\"options\":\"\",\"category\":\"Display\",\"default\":\"\",\"value\":\"\",\"sortorder\":\"100\",\"i18n\":\"1\",\"expression\":\"1\",\"classes\":[\"form-control\"] } },\"hidden\":{ \"name\":\"hidden\",\"title\":\"Always hide this question\",\"inputtype\":\"switch\",\"formElementId\":\"hidden\",\"formElementName\":\"false\",\"formElementHelp\":\"Hide this question at any time. This is useful for including data using answer prefilling.\",\"formElementValue\":\"0\",\"aFormElementOptions\":{ \"name\":\"hidden\",\"options\":{ \"option\":[{ \"value\":\"0\",\"text\":\"No\" },{ \"value\":\"1\",\"text\":\"Yes\" }] },\"category\":\"Display\",\"default\":\"0\",\"value\":\"\",\"sortorder\":\"101\",\"classes\":[\"form-control\"] } },\"cssclass\":{ \"name\":\"cssclass\",\"title\":\"CSS class(es)\",\"inputtype\":\"text\",\"formElementId\":\"cssclass\",\"formElementName\":\"false\",\"formElementHelp\":\"Add additional CSS class(es) for this question. Use a space between multiple CSS class names. You\\n                may use expressions - remember this part is static.\\n            \",\"formElementValue\":\"\",\"aFormElementOptions\":{ \"name\":\"cssclass\",\"options\":\"\",\"category\":\"Display\",\"default\":\"\",\"value\":\"\",\"sortorder\":\"102\",\"expression\":\"1\",\"classes\":[\"form-control\"] } },\"printable_help\":{ \"name\":\"printable_help\",\"title\":\"Relevance help for printable survey\",\"inputtype\":\"text\",\"formElementId\":\"printable_help\",\"formElementName\":\"false\",\"formElementHelp\":\"In the printable version the condition is being replaced with this explanation text.\",\"formElementValue\":\"\",\"aFormElementOptions\":{ \"name\":\"printable_help\",\"options\":\"\",\"category\":\"Display\",\"value\":\"\",\"sortorder\":\"201\",\"i18n\":\"1\",\"expression\":\"1\",\"classes\":[\"form-control\"] } } },\"Logic\":{ \"other_numbers_only\":{ \"name\":\"other_numbers_only\",\"title\":\"Numbers only for \'Other\'\",\"inputtype\":\"switch\",\"formElementId\":\"other_numbers_only\",\"formElementName\":\"false\",\"formElementHelp\":\"Allow only numerical input for &#039;Other&#039; text\",\"formElementValue\":\"0\",\"aFormElementOptions\":{ \"name\":\"other_numbers_only\",\"options\":{ \"option\":[{ \"value\":\"0\",\"text\":\"No\" },{ \"value\":\"1\",\"text\":\"Yes\" }] },\"category\":\"Logic\",\"default\":\"0\",\"value\":\"\",\"sortorder\":\"100\",\"classes\":[\"form-control\"] } },\"other_comment_mandatory\":{ \"name\":\"other_comment_mandatory\",\"title\":\"\'Other:\' comment mandatory\",\"inputtype\":\"switch\",\"formElementId\":\"other_comment_mandatory\",\"formElementName\":\"false\",\"formElementHelp\":\"Make the &#039;Other:&#039; comment field mandatory when the &#039;Other:&#039;\\n                option is active\\n            \",\"formElementValue\":\"0\",\"aFormElementOptions\":{ \"name\":\"other_comment_mandatory\",\"options\":{ \"option\":[{ \"value\":\"0\",\"text\":\"No\" },{ \"value\":\"1\",\"text\":\"Yes\" }] },\"category\":\"Logic\",\"default\":\"0\",\"value\":\"\",\"sortorder\":\"100\",\"classes\":[\"form-control\"] } },\"array_filter_style\":{ \"name\":\"array_filter_style\",\"title\":\"Array filter style\",\"inputtype\":\"buttongroup\",\"formElementId\":\"array_filter_style\",\"formElementName\":\"false\",\"formElementHelp\":\"Specify how array-filtered sub-questions should be displayed\",\"formElementValue\":\"0\",\"aFormElementOptions\":{ \"name\":\"array_filter_style\",\"options\":{ \"option\":[{ \"value\":\"0\",\"text\":\"Hidden\" },{ \"value\":\"1\",\"text\":\"Disabled\" }] },\"category\":\"Logic\",\"default\":\"0\",\"value\":\"\",\"sortorder\":\"100\",\"classes\":[\"form-control\"] } },\"array_filter_exclude\":{ \"name\":\"array_filter_exclude\",\"title\":\"Array filter exclusion\",\"inputtype\":\"text\",\"formElementId\":\"array_filter_exclude\",\"formElementName\":\"false\",\"formElementHelp\":\"Enter the code(s) of Multiple choice question(s) (separated by semicolons) to exclude the matching answer options in this question.\",\"formElementValue\":\"\",\"aFormElementOptions\":{ \"name\":\"array_filter_exclude\",\"options\":\"\",\"category\":\"Logic\",\"default\":\"\",\"value\":\"\",\"sortorder\":\"100\",\"classes\":[\"form-control\"] } },\"array_filter\":{ \"name\":\"array_filter\",\"title\":\"Array filter\",\"inputtype\":\"text\",\"formElementId\":\"array_filter\",\"formElementName\":\"false\",\"formElementHelp\":\"Enter the code(s) of Multiple choice question(s) (separated by semicolons) to only show the matching answer options in this question.\",\"formElementValue\":\"\",\"aFormElementOptions\":{ \"name\":\"array_filter\",\"options\":\"\",\"category\":\"Logic\",\"default\":\"\",\"value\":\"\",\"sortorder\":\"100\",\"classes\":[\"form-control\"] } },\"random_group\":{ \"name\":\"random_group\",\"title\":\"Randomization group name\",\"inputtype\":\"text\",\"formElementId\":\"random_group\",\"formElementName\":\"false\",\"formElementHelp\":\"Place questions into a specified randomization group, all questions included in the specified\\n                group will appear in a random order\\n            \",\"formElementValue\":\"\",\"aFormElementOptions\":{ \"name\":\"random_group\",\"options\":\"\",\"category\":\"Logic\",\"default\":\"\",\"value\":\"\",\"sortorder\":\"180\",\"classes\":[\"form-control\"] } },\"em_validation_q\":{ \"name\":\"em_validation_q\",\"title\":\"Question validation equation\",\"inputtype\":\"textarea\",\"formElementId\":\"em_validation_q\",\"formElementName\":\"false\",\"formElementHelp\":\"Enter a boolean equation to validate the whole question.\",\"formElementValue\":\"\",\"aFormElementOptions\":{ \"name\":\"em_validation_q\",\"options\":\"\",\"category\":\"Logic\",\"default\":\"\",\"value\":\"\",\"sortorder\":\"200\",\"expression\":\"2\",\"classes\":[\"form-control\"],\"inputGroup\":{ \"prefix\":\"{ \",\"suffix\":\" }\" } } },\"em_validation_q_tip\":{ \"name\":\"em_validation_q_tip\",\"title\":\"Question validation tip\",\"inputtype\":\"textarea\",\"formElementId\":\"em_validation_q_tip\",\"formElementName\":\"false\",\"formElementHelp\":\"This is a hint text that will be shown to the participant describing the question validation\\n                equation.\\n            \",\"formElementValue\":\"\",\"aFormElementOptions\":{ \"name\":\"em_validation_q_tip\",\"options\":\"\",\"category\":\"Logic\",\"default\":\"\",\"value\":\"\",\"sortorder\":\"210\",\"i18n\":\"1\",\"expression\":\"1\",\"classes\":[\"form-control\"] } } },\"Other\":{ \"page_break\":{ \"name\":\"page_break\",\"title\":\"Insert page break in printable view\",\"inputtype\":\"switch\",\"formElementId\":\"page_break\",\"formElementName\":\"false\",\"formElementHelp\":\"Insert a page break before this question in printable view by setting this to Yes.\",\"formElementValue\":\"0\",\"aFormElementOptions\":{ \"name\":\"page_break\",\"options\":{ \"option\":[{ \"value\":\"0\",\"text\":\"No\" },{ \"value\":\"1\",\"text\":\"Yes\" }] },\"category\":\"Other\",\"default\":\"0\",\"value\":\"\",\"sortorder\":\"100\",\"classes\":[\"form-control\"] } },\"scale_export\":{ \"name\":\"scale_export\",\"title\":\"SPSS export scale type\",\"inputtype\":\"singleselect\",\"formElementId\":\"scale_export\",\"formElementName\":\"false\",\"formElementHelp\":\"Set a specific SPSS export scale type for this question\",\"formElementValue\":\"0\",\"aFormElementOptions\":{ \"name\":\"scale_export\",\"options\":{ \"option\":[{ \"value\":\"0\",\"text\":\"Default\" },{ \"value\":\"1\",\"text\":\"Nominal\" },{ \"value\":\"2\",\"text\":\"Ordinal\" },{ \"value\":\"3\",\"text\":\"Scale\" }] },\"category\":\"Other\",\"default\":\"0\",\"value\":\"\",\"sortorder\":\"100\",\"classes\":[\"form-control\"] } } },\"Statistics\":{ \"public_statistics\":{ \"name\":\"public_statistics\",\"title\":\"Show in public statistics\",\"inputtype\":\"switch\",\"formElementId\":\"public_statistics\",\"formElementName\":\"false\",\"formElementHelp\":\"Show statistics of this question in the public statistics page\",\"formElementValue\":\"0\",\"aFormElementOptions\":{ \"name\":\"public_statistics\",\"options\":{ \"option\":[{ \"value\":\"0\",\"text\":\"No\" },{ \"value\":\"1\",\"text\":\"Yes\" }] },\"category\":\"Statistics\",\"default\":\"0\",\"value\":\"\",\"sortorder\":\"80\",\"classes\":[\"form-control\"] } },\"statistics_showgraph\":{ \"name\":\"statistics_showgraph\",\"title\":\"Display chart\",\"inputtype\":\"switch\",\"formElementId\":\"statistics_showgraph\",\"formElementName\":\"false\",\"formElementHelp\":\"Display a chart in the statistics?\",\"formElementValue\":\"1\",\"aFormElementOptions\":{ \"name\":\"statistics_showgraph\",\"options\":{ \"option\":[{ \"value\":\"0\",\"text\":\"No\" },{ \"value\":\"1\",\"text\":\"Yes\" }] },\"category\":\"Statistics\",\"default\":\"1\",\"value\":\"\",\"sortorder\":\"101\",\"classes\":[\"form-control\"] } },\"statistics_graphtype\":{ \"name\":\"statistics_graphtype\",\"title\":\"Chart type\",\"inputtype\":\"singleselect\",\"formElementId\":\"statistics_graphtype\",\"formElementName\":\"false\",\"formElementHelp\":\"Select the type of chart to be displayed\",\"formElementValue\":\"0\",\"aFormElementOptions\":{ \"name\":\"statistics_graphtype\",\"options\":{ \"option\":[{ \"value\":\"0\",\"text\":\"Bar chart\" },{ \"value\":\"1\",\"text\":\"Pie chart\" },{ \"value\":\"2\",\"text\":\"Radar\" },{ \"value\":\"3\",\"text\":\"Line\" },{ \"value\":\"4\",\"text\":\"PolarArea\" },{ \"value\":\"5\",\"text\":\"Doughnut\" }] },\"category\":\"Statistics\",\"default\":\"0\",\"value\":\"\",\"sortorder\":\"102\",\"classes\":[\"form-control\"] } } },\"Timer\":{ \"time_limit\":{ \"name\":\"time_limit\",\"title\":\"Time limit\",\"inputtype\":\"integer\",\"formElementId\":\"time_limit\",\"formElementName\":\"false\",\"formElementHelp\":\"Limit time to answer question (in seconds)\",\"formElementValue\":\"\",\"aFormElementOptions\":{ \"name\":\"time_limit\",\"options\":\"\",\"category\":\"Timer\",\"default\":\"\",\"value\":\"\",\"sortorder\":\"90\",\"classes\":[\"form-control\"] } },\"time_limit_action\":{ \"name\":\"time_limit_action\",\"title\":\"Time limit action\",\"inputtype\":\"singleselect\",\"formElementId\":\"time_limit_action\",\"formElementName\":\"false\",\"formElementHelp\":\"Action to perform when time limit is up\",\"formElementValue\":\"1\",\"aFormElementOptions\":{ \"name\":\"time_limit_action\",\"options\":{ \"option\":[{ \"value\":\"1\",\"text\":\"Warn and move on\" },{ \"value\":\"2\",\"text\":\"Move on without warning\" },{ \"value\":\"3\",\"text\":\"Disable only\" }] },\"category\":\"Timer\",\"default\":\"1\",\"value\":\"\",\"sortorder\":\"92\",\"classes\":[\"form-control\"] } },\"time_limit_disable_next\":{ \"name\":\"time_limit_disable_next\",\"title\":\"Time limit disable next\",\"inputtype\":\"switch\",\"formElementId\":\"time_limit_disable_next\",\"formElementName\":\"false\",\"formElementHelp\":\"Disable the next button until time limit expires\",\"formElementValue\":\"0\",\"aFormElementOptions\":{ \"name\":\"time_limit_disable_next\",\"options\":{ \"option\":[{ \"value\":\"0\",\"text\":\"No\" },{ \"value\":\"1\",\"text\":\"Yes\" }] },\"category\":\"Timer\",\"default\":\"0\",\"value\":\"\",\"sortorder\":\"94\",\"classes\":[\"form-control\"] } },\"time_limit_disable_prev\":{ \"name\":\"time_limit_disable_prev\",\"title\":\"Time limit disable prev\",\"inputtype\":\"switch\",\"formElementId\":\"time_limit_disable_prev\",\"formElementName\":\"false\",\"formElementHelp\":\"Disable the prev button until the time limit expires\",\"formElementValue\":\"0\",\"aFormElementOptions\":{ \"name\":\"time_limit_disable_prev\",\"options\":{ \"option\":[{ \"value\":\"0\",\"text\":\"No\" },{ \"value\":\"1\",\"text\":\"Yes\" }] },\"category\":\"Timer\",\"default\":\"0\",\"value\":\"\",\"sortorder\":\"96\",\"classes\":[\"form-control\"] } },\"time_limit_countdown_message\":{ \"name\":\"time_limit_countdown_message\",\"title\":\"Time limit countdown message\",\"inputtype\":\"textarea\",\"formElementId\":\"time_limit_countdown_message\",\"formElementName\":\"false\",\"formElementHelp\":\"The text message that displays in the countdown timer during the countdown\",\"formElementValue\":\"\",\"aFormElementOptions\":{ \"name\":\"time_limit_countdown_message\",\"options\":\"\",\"category\":\"Timer\",\"default\":\"\",\"value\":\"\",\"sortorder\":\"98\",\"i18n\":\"1\",\"expression\":\"1\",\"classes\":[\"form-control\"] } },\"time_limit_timer_style\":{ \"name\":\"time_limit_timer_style\",\"title\":\"Time limit timer CSS style\",\"inputtype\":\"textarea\",\"formElementId\":\"time_limit_timer_style\",\"formElementName\":\"false\",\"formElementHelp\":\"CSS Style for the message that displays in the countdown timer during the countdown\",\"formElementValue\":\"\",\"aFormElementOptions\":{ \"name\":\"time_limit_timer_style\",\"options\":\"\",\"category\":\"Timer\",\"default\":\"\",\"value\":\"\",\"sortorder\":\"100\",\"classes\":[\"form-control\"] } },\"time_limit_message_delay\":{ \"name\":\"time_limit_message_delay\",\"title\":\"Time limit expiry message display time\",\"inputtype\":\"integer\",\"formElementId\":\"time_limit_message_delay\",\"formElementName\":\"false\",\"formElementHelp\":\"Display the &#039;time limit expiry message&#039; for this many seconds before performing\\n                the &#039;time limit action&#039; (defaults to 1 second if left blank)\\n            \",\"formElementValue\":\"\",\"aFormElementOptions\":{ \"name\":\"time_limit_message_delay\",\"options\":\"\",\"category\":\"Timer\",\"default\":\"\",\"value\":\"\",\"sortorder\":\"102\",\"classes\":[\"form-control\"] } },\"time_limit_message\":{ \"name\":\"time_limit_message\",\"title\":\"Time limit expiry message\",\"inputtype\":\"textarea\",\"formElementId\":\"time_limit_message\",\"formElementName\":\"false\",\"formElementHelp\":\"The message to display when the time limit has expired (a default message will display if this\\n                setting is left blank)\\n            \",\"formElementValue\":\"\",\"aFormElementOptions\":{ \"name\":\"time_limit_message\",\"options\":\"\",\"category\":\"Timer\",\"default\":\"\",\"value\":\"\",\"sortorder\":\"104\",\"i18n\":\"1\",\"expression\":\"1\",\"classes\":[\"form-control\"] } },\"time_limit_message_style\":{ \"name\":\"time_limit_message_style\",\"title\":\"Time limit message CSS style\",\"inputtype\":\"textarea\",\"formElementId\":\"time_limit_message_style\",\"formElementName\":\"false\",\"formElementHelp\":\"CSS style for the &#039;time limit expiry message&#039;\",\"formElementValue\":\"\",\"aFormElementOptions\":{ \"name\":\"time_limit_message_style\",\"options\":\"\",\"category\":\"Timer\",\"default\":\"\",\"value\":\"\",\"sortorder\":\"106\",\"classes\":[\"form-control\"] } },\"time_limit_warning\":{ \"name\":\"time_limit_warning\",\"title\":\"1st time limit warning message timer\",\"inputtype\":\"integer\",\"formElementId\":\"time_limit_warning\",\"formElementName\":\"false\",\"formElementHelp\":\"Display a &#039;time limit warning&#039; when there are this many seconds remaining in the\\n                countdown (warning will not display if left blank)\\n            \",\"formElementValue\":\"\",\"aFormElementOptions\":{ \"name\":\"time_limit_warning\",\"options\":\"\",\"category\":\"Timer\",\"default\":\"\",\"value\":\"\",\"sortorder\":\"108\",\"classes\":[\"form-control\"] } },\"time_limit_warning_display_time\":{ \"name\":\"time_limit_warning_display_time\",\"title\":\"1st time limit warning message display time\",\"inputtype\":\"integer\",\"formElementId\":\"time_limit_warning_display_time\",\"formElementName\":\"false\",\"formElementHelp\":\"The &#039;time limit warning&#039; will stay visible for this many seconds (will not turn\\n                off if this setting is left blank)\\n            \",\"formElementValue\":\"\",\"aFormElementOptions\":{ \"name\":\"time_limit_warning_display_time\",\"options\":\"\",\"category\":\"Timer\",\"default\":\"\",\"value\":\"\",\"sortorder\":\"110\",\"classes\":[\"form-control\"] } },\"time_limit_warning_message\":{ \"name\":\"time_limit_warning_message\",\"title\":\"1st time limit warning message\",\"inputtype\":\"textarea\",\"formElementId\":\"time_limit_warning_message\",\"formElementName\":\"false\",\"formElementHelp\":\"The message to display as a &#039;time limit warning&#039; (a default warning will display\\n                if this is left blank)\\n            \",\"formElementValue\":\"\",\"aFormElementOptions\":{ \"name\":\"time_limit_warning_message\",\"options\":\"\",\"category\":\"Timer\",\"default\":\"\",\"value\":\"\",\"sortorder\":\"112\",\"i18n\":\"1\",\"expression\":\"1\",\"classes\":[\"form-control\"] } },\"time_limit_warning_style\":{ \"name\":\"time_limit_warning_style\",\"title\":\"1st time limit warning CSS style\",\"inputtype\":\"textarea\",\"formElementId\":\"time_limit_warning_style\",\"formElementName\":\"false\",\"formElementHelp\":\"CSS style used when the &#039;time limit warning&#039; message is displayed\",\"formElementValue\":\"\",\"aFormElementOptions\":{ \"name\":\"time_limit_warning_style\",\"options\":\"\",\"category\":\"Timer\",\"default\":\"\",\"value\":\"\",\"sortorder\":\"114\",\"classes\":[\"form-control\"] } },\"time_limit_warning_2\":{ \"name\":\"time_limit_warning_2\",\"title\":\"2nd time limit warning message timer\",\"inputtype\":\"integer\",\"formElementId\":\"time_limit_warning_2\",\"formElementName\":\"false\",\"formElementHelp\":\"Display the 2nd &#039;time limit warning&#039; when there are this many seconds remaining\\n                in the countdown (warning will not display if left blank)\\n            \",\"formElementValue\":\"\",\"aFormElementOptions\":{ \"name\":\"time_limit_warning_2\",\"options\":\"\",\"category\":\"Timer\",\"default\":\"\",\"value\":\"\",\"sortorder\":\"116\",\"classes\":[\"form-control\"] } },\"time_limit_warning_2_display_time\":{ \"name\":\"time_limit_warning_2_display_time\",\"title\":\"2nd time limit warning message display time\",\"inputtype\":\"integer\",\"formElementId\":\"time_limit_warning_2_display_time\",\"formElementName\":\"false\",\"formElementHelp\":\"The 2nd &#039;time limit warning&#039; will stay visible for this many seconds (will not\\n                turn off if this setting is left blank)\\n            \",\"formElementValue\":\"\",\"aFormElementOptions\":{ \"name\":\"time_limit_warning_2_display_time\",\"options\":\"\",\"category\":\"Timer\",\"default\":\"\",\"value\":\"\",\"sortorder\":\"118\",\"classes\":[\"form-control\"] } },\"time_limit_warning_2_message\":{ \"name\":\"time_limit_warning_2_message\",\"title\":\"2nd time limit warning message\",\"inputtype\":\"textarea\",\"formElementId\":\"time_limit_warning_2_message\",\"formElementName\":\"false\",\"formElementHelp\":\"The 2nd message to display as a &#039;time limit warning&#039; (a default warning will\\n                display if this is left blank)\\n            \",\"formElementValue\":\"\",\"aFormElementOptions\":{ \"name\":\"time_limit_warning_2_message\",\"options\":\"\",\"category\":\"Timer\",\"default\":\"\",\"value\":\"\",\"sortorder\":\"120\",\"i18n\":\"1\",\"expression\":\"1\",\"classes\":[\"form-control\"] } },\"time_limit_warning_2_style\":{ \"name\":\"time_limit_warning_2_style\",\"title\":\"2nd time limit warning CSS style\",\"inputtype\":\"textarea\",\"formElementId\":\"time_limit_warning_2_style\",\"formElementName\":\"false\",\"formElementHelp\":\"CSS style used when the 2nd &#039;time limit warning&#039; message is displayed\",\"formElementValue\":\"\",\"aFormElementOptions\":{ \"name\":\"time_limit_warning_2_style\",\"options\":\"\",\"category\":\"Timer\",\"default\":\"\",\"value\":\"\",\"sortorder\":\"122\",\"classes\":[\"form-control\"] } } } }'),(3,1,NULL,NULL,'lock_organizer','1');
/*!40000 ALTER TABLE `lsud_settings_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_survey_855621`
--

DROP TABLE IF EXISTS `lsud_survey_855621`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_survey_855621` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `submitdate` datetime DEFAULT NULL,
  `lastpage` int(11) DEFAULT NULL,
  `startlanguage` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `seed` varchar(31) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `startdate` datetime NOT NULL,
  `datestamp` datetime NOT NULL,
  `ipaddr` text COLLATE utf8mb4_unicode_ci,
  `refurl` text COLLATE utf8mb4_unicode_ci,
  `855621X1X1` decimal(30,10) DEFAULT NULL,
  `855621X1X83` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X1X3` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X1X3other` text COLLATE utf8mb4_unicode_ci,
  `855621X1X4` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X1X6` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X1X7` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X1X7other` text COLLATE utf8mb4_unicode_ci,
  `855621X1X8` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X1X8other` text COLLATE utf8mb4_unicode_ci,
  `855621X1X9` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X1X9other` text COLLATE utf8mb4_unicode_ci,
  `855621X1X10` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X1X10other` text COLLATE utf8mb4_unicode_ci,
  `855621X1X11` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X1X11other` text COLLATE utf8mb4_unicode_ci,
  `855621X1X12` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X1X13` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X1X14` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X1X15` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X1X16` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X1X17` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X1X18` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X1X19` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X1X20` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X1X20other` text COLLATE utf8mb4_unicode_ci,
  `855621X1X21` decimal(30,10) DEFAULT NULL,
  `855621X2X221` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X2X222` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X2X223` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X2X224` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X2X225` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X2X226` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X2X227` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X2X228` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X2X229` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X2X2210` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X2X2211` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X2X2212` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X2X2213` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X2X2214` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X2X2215` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X2X2216` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X2X2217` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X2X2218` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X2X2219` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X2X2220` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X3X231` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X3X232` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X3X233` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X3X234` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X3X235` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X3X236` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X3X237` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X3X238` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X4X241` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X4X242` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X4X243` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X4X244` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X4X245` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X4X246` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X4X247` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X4X248` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X4X249` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X4X2410` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X4X2411` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X4X2412` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X4X2413` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X4X2414` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X4X2415` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X5X251` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X5X252` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X5X253` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X5X254` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X5X255` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X5X256` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X5X257` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X5X258` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X5X259` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X5X2510` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X5X2511` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X5X2512` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `855621X5X2612` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_survey_token_855621_48756` (`token`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_survey_855621`
--

LOCK TABLES `lsud_survey_855621` WRITE;
/*!40000 ALTER TABLE `lsud_survey_855621` DISABLE KEYS */;
INSERT INTO `lsud_survey_855621` (`id`, `token`, `submitdate`, `lastpage`, `startlanguage`, `seed`, `startdate`, `datestamp`, `ipaddr`, `refurl`, `855621X1X1`, `855621X1X83`, `855621X1X3`, `855621X1X3other`, `855621X1X4`, `855621X1X6`, `855621X1X7`, `855621X1X7other`, `855621X1X8`, `855621X1X8other`, `855621X1X9`, `855621X1X9other`, `855621X1X10`, `855621X1X10other`, `855621X1X11`, `855621X1X11other`, `855621X1X12`, `855621X1X13`, `855621X1X14`, `855621X1X15`, `855621X1X16`, `855621X1X17`, `855621X1X18`, `855621X1X19`, `855621X1X20`, `855621X1X20other`, `855621X1X21`, `855621X2X221`, `855621X2X222`, `855621X2X223`, `855621X2X224`, `855621X2X225`, `855621X2X226`, `855621X2X227`, `855621X2X228`, `855621X2X229`, `855621X2X2210`, `855621X2X2211`, `855621X2X2212`, `855621X2X2213`, `855621X2X2214`, `855621X2X2215`, `855621X2X2216`, `855621X2X2217`, `855621X2X2218`, `855621X2X2219`, `855621X2X2220`, `855621X3X231`, `855621X3X232`, `855621X3X233`, `855621X3X234`, `855621X3X235`, `855621X3X236`, `855621X3X237`, `855621X3X238`, `855621X4X241`, `855621X4X242`, `855621X4X243`, `855621X4X244`, `855621X4X245`, `855621X4X246`, `855621X4X247`, `855621X4X248`, `855621X4X249`, `855621X4X2410`, `855621X4X2411`, `855621X4X2412`, `855621X4X2413`, `855621X4X2414`, `855621X4X2415`, `855621X5X251`, `855621X5X252`, `855621X5X253`, `855621X5X254`, `855621X5X255`, `855621X5X256`, `855621X5X257`, `855621X5X258`, `855621X5X259`, `855621X5X2510`, `855621X5X2511`, `855621X5X2512`, `855621X5X2612`) VALUES (1,NULL,'2020-11-20 15:47:01',5,'es','1921476079','2020-11-20 15:45:08','2020-11-20 15:47:01','181.175.138.90','https://encuestas.udla-covid.org/index.php/admin/survey/sa/view/surveyid/855621',45.0000000000,'1','1','','3','F','1','','1','','1','','1','','1','','1','1','1','1','1','1','1','1','1','',45.0000000000,'1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','2'),(2,NULL,'2020-11-20 15:51:39',5,'es','1302215341','2020-11-20 15:49:59','2020-11-20 15:51:39','181.175.138.90','https://encuestas.udla-covid.org/index.php/admin/survey/sa/rendersidemenulink/subaction/surveytexts/surveyid/855621',34.0000000000,'1','1','','18','M','1','','1','','1','','3','','4','','3','1','2','2',NULL,NULL,'2','1','2','',45.0000000000,'1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1');
/*!40000 ALTER TABLE `lsud_survey_855621` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_survey_855621_timings`
--

DROP TABLE IF EXISTS `lsud_survey_855621_timings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_survey_855621_timings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `interviewtime` float DEFAULT NULL,
  `855621X1time` float DEFAULT NULL,
  `855621X1X1time` float DEFAULT NULL,
  `855621X1X83time` float DEFAULT NULL,
  `855621X1X3time` float DEFAULT NULL,
  `855621X1X4time` float DEFAULT NULL,
  `855621X1X6time` float DEFAULT NULL,
  `855621X1X7time` float DEFAULT NULL,
  `855621X1X8time` float DEFAULT NULL,
  `855621X1X9time` float DEFAULT NULL,
  `855621X1X10time` float DEFAULT NULL,
  `855621X1X11time` float DEFAULT NULL,
  `855621X1X12time` float DEFAULT NULL,
  `855621X1X13time` float DEFAULT NULL,
  `855621X1X14time` float DEFAULT NULL,
  `855621X1X15time` float DEFAULT NULL,
  `855621X1X16time` float DEFAULT NULL,
  `855621X1X17time` float DEFAULT NULL,
  `855621X1X18time` float DEFAULT NULL,
  `855621X1X19time` float DEFAULT NULL,
  `855621X1X20time` float DEFAULT NULL,
  `855621X1X21time` float DEFAULT NULL,
  `855621X2time` float DEFAULT NULL,
  `855621X2X22time` float DEFAULT NULL,
  `855621X3time` float DEFAULT NULL,
  `855621X3X23time` float DEFAULT NULL,
  `855621X4time` float DEFAULT NULL,
  `855621X4X24time` float DEFAULT NULL,
  `855621X5time` float DEFAULT NULL,
  `855621X5X25time` float DEFAULT NULL,
  `855621X5X26time` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_survey_855621_timings`
--

LOCK TABLES `lsud_survey_855621_timings` WRITE;
/*!40000 ALTER TABLE `lsud_survey_855621_timings` DISABLE KEYS */;
INSERT INTO `lsud_survey_855621_timings` (`id`, `interviewtime`, `855621X1time`, `855621X1X1time`, `855621X1X83time`, `855621X1X3time`, `855621X1X4time`, `855621X1X6time`, `855621X1X7time`, `855621X1X8time`, `855621X1X9time`, `855621X1X10time`, `855621X1X11time`, `855621X1X12time`, `855621X1X13time`, `855621X1X14time`, `855621X1X15time`, `855621X1X16time`, `855621X1X17time`, `855621X1X18time`, `855621X1X19time`, `855621X1X20time`, `855621X1X21time`, `855621X2time`, `855621X2X22time`, `855621X3time`, `855621X3X23time`, `855621X4time`, `855621X4X24time`, `855621X5time`, `855621X5X25time`, `855621X5X26time`) VALUES (1,115.83,53.89,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,20.61,NULL,7.93,NULL,15.64,NULL,17.76,NULL,NULL),(2,100.83,43.73,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,19.12,NULL,8.61,NULL,15.31,NULL,14.06,NULL,NULL);
/*!40000 ALTER TABLE `lsud_survey_855621_timings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_survey_links`
--

DROP TABLE IF EXISTS `lsud_survey_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_survey_links` (
  `participant_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token_id` int(11) NOT NULL,
  `survey_id` int(11) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_invited` datetime DEFAULT NULL,
  `date_completed` datetime DEFAULT NULL,
  PRIMARY KEY (`participant_id`,`token_id`,`survey_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_survey_links`
--

LOCK TABLES `lsud_survey_links` WRITE;
/*!40000 ALTER TABLE `lsud_survey_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `lsud_survey_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_survey_url_parameters`
--

DROP TABLE IF EXISTS `lsud_survey_url_parameters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_survey_url_parameters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) NOT NULL,
  `parameter` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `targetqid` int(11) DEFAULT NULL,
  `targetsqid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_survey_url_parameters`
--

LOCK TABLES `lsud_survey_url_parameters` WRITE;
/*!40000 ALTER TABLE `lsud_survey_url_parameters` DISABLE KEYS */;
/*!40000 ALTER TABLE `lsud_survey_url_parameters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_surveymenu`
--

DROP TABLE IF EXISTS `lsud_surveymenu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_surveymenu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `survey_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ordering` int(11) DEFAULT '0',
  `level` int(11) DEFAULT '0',
  `title` varchar(168) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `position` varchar(192) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'side',
  `description` text COLLATE utf8mb4_unicode_ci,
  `showincollapse` int(11) DEFAULT '0',
  `active` int(11) NOT NULL DEFAULT '0',
  `changed_at` datetime DEFAULT NULL,
  `changed_by` int(11) NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `lsud_surveymenu_name` (`name`),
  KEY `lsud_idx2_surveymenu` (`title`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_surveymenu`
--

LOCK TABLES `lsud_surveymenu` WRITE;
/*!40000 ALTER TABLE `lsud_surveymenu` DISABLE KEYS */;
INSERT INTO `lsud_surveymenu` (`id`, `parent_id`, `survey_id`, `user_id`, `name`, `ordering`, `level`, `title`, `position`, `description`, `showincollapse`, `active`, `changed_at`, `changed_by`, `created_at`, `created_by`) VALUES (1,NULL,NULL,NULL,'settings',1,0,'Survey settings','side','Survey settings',1,1,'2020-11-20 12:16:46',0,'2020-11-20 12:16:46',0),(2,NULL,NULL,NULL,'mainmenu',2,0,'Survey menu','side','Main survey menu',1,1,'2020-11-20 12:16:46',0,'2020-11-20 12:16:46',0),(3,NULL,NULL,NULL,'quickmenu',3,0,'Quick menu','collapsed','Quick menu',0,1,'2020-11-20 12:16:46',0,'2020-11-20 12:16:46',0);
/*!40000 ALTER TABLE `lsud_surveymenu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_surveymenu_entries`
--

DROP TABLE IF EXISTS `lsud_surveymenu_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_surveymenu_entries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `ordering` int(11) DEFAULT '0',
  `name` varchar(168) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `title` varchar(168) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_title` varchar(168) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_description` text COLLATE utf8mb4_unicode_ci,
  `menu_icon` varchar(192) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_icon_type` varchar(192) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_class` varchar(192) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_link` varchar(192) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `action` varchar(192) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `template` varchar(192) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `partial` varchar(192) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `classes` varchar(192) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `permission` varchar(192) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `permission_grade` varchar(192) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data` text COLLATE utf8mb4_unicode_ci,
  `getdatamethod` varchar(192) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `language` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en-GB',
  `showincollapse` int(11) DEFAULT '0',
  `active` int(11) NOT NULL DEFAULT '0',
  `changed_at` datetime DEFAULT NULL,
  `changed_by` int(11) NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `lsud_surveymenu_entries_name` (`name`),
  KEY `lsud_idx1_surveymenu_entries` (`menu_id`),
  KEY `lsud_idx5_surveymenu_entries` (`menu_title`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_surveymenu_entries`
--

LOCK TABLES `lsud_surveymenu_entries` WRITE;
/*!40000 ALTER TABLE `lsud_surveymenu_entries` DISABLE KEYS */;
INSERT INTO `lsud_surveymenu_entries` (`id`, `menu_id`, `user_id`, `ordering`, `name`, `title`, `menu_title`, `menu_description`, `menu_icon`, `menu_icon_type`, `menu_class`, `menu_link`, `action`, `template`, `partial`, `classes`, `permission`, `permission_grade`, `data`, `getdatamethod`, `language`, `showincollapse`, `active`, `changed_at`, `changed_by`, `created_at`, `created_by`) VALUES (1,1,NULL,1,'overview','Survey overview','Overview','Open the general survey overview','list','fontawesome','','admin/survey/sa/view','','','','','','','{\"render\": { \"link\": {\"data\": {\"surveyid\": [\"survey\",\"sid\"]}}}}','','en-GB',0,1,'2020-11-20 12:16:46',0,'2020-11-20 12:16:46',0),(2,1,NULL,2,'generalsettings','General survey settings','General settings','Open general survey settings','gears','fontawesome','','','updatesurveylocalesettings_generalsettings','editLocalSettings_main_view','/admin/survey/subview/accordion/_generaloptions_panel','','surveysettings','read',NULL,'_generalTabEditSurvey','en-GB',1,1,'2020-11-20 12:16:46',0,'2020-11-20 12:16:46',0),(3,1,NULL,3,'surveytexts','Survey text elements','Text elements','Survey text elements','file-text-o','fontawesome','','','updatesurveylocalesettings','editLocalSettings_main_view','/admin/survey/subview/tab_edit_view','','surveylocale','read',NULL,'_getTextEditData','en-GB',1,1,'2020-11-20 12:16:46',0,'2020-11-20 12:16:46',0),(4,1,NULL,4,'datasecurity','Data policy settings','Data policy settings','Edit data policy settings','shield','fontawesome','','','updatesurveylocalesettings','editLocalSettings_main_view','/admin/survey/subview/tab_edit_view_datasecurity','','surveylocale','read',NULL,'_getDataSecurityEditData','en-GB',1,1,'2020-11-20 12:16:46',0,'2020-11-20 12:16:46',0),(5,1,NULL,5,'theme_options','Theme options','Theme options','Edit theme options for this survey','paint-brush','fontawesome','','admin/themeoptions/sa/updatesurvey','','','','','surveysettings','update','{\"render\": {\"link\": { \"pjaxed\": true, \"data\": {\"surveyid\": [\"survey\",\"sid\"], \"gsid\":[\"survey\",\"gsid\"]}}}}','','en-GB',0,1,'2020-11-20 12:16:46',0,'2020-11-20 12:16:46',0),(6,1,NULL,6,'presentation','Presentation & navigation settings','Presentation','Edit presentation and navigation settings','eye-slash','fontawesome','','','updatesurveylocalesettings','editLocalSettings_main_view','/admin/survey/subview/accordion/_presentation_panel','','surveylocale','read',NULL,'_tabPresentationNavigation','en-GB',0,1,'2020-11-20 12:16:46',0,'2020-11-20 12:16:46',0),(7,1,NULL,7,'tokens','Survey participant settings','Participant settings','Set additional options for survey participants','users','fontawesome','','','updatesurveylocalesettings','editLocalSettings_main_view','/admin/survey/subview/accordion/_tokens_panel','','surveylocale','read',NULL,'_tabTokens','en-GB',0,1,'2020-11-20 12:16:46',0,'2020-11-20 12:16:46',0),(8,1,NULL,8,'notification','Notification and data management settings','Notifications & data','Edit settings for notification and data management','feed','fontawesome','','','updatesurveylocalesettings','editLocalSettings_main_view','/admin/survey/subview/accordion/_notification_panel','','surveylocale','read',NULL,'_tabNotificationDataManagement','en-GB',0,1,'2020-11-20 12:16:46',0,'2020-11-20 12:16:46',0),(9,1,NULL,9,'publication','Publication & access control settings','Publication & access','Edit settings for publication and access control','key','fontawesome','','','updatesurveylocalesettings','editLocalSettings_main_view','/admin/survey/subview/accordion/_publication_panel','','surveylocale','read',NULL,'_tabPublicationAccess','en-GB',0,1,'2020-11-20 12:16:46',0,'2020-11-20 12:16:46',0),(10,2,NULL,1,'listQuestions','Question list','Question list','List questions','list','fontawesome','','admin/survey/sa/listquestions','','','','','surveycontent','read','{\"render\": { \"link\": {\"data\": {\"surveyid\": [\"survey\",\"sid\"]}}}}','','en-GB',1,1,'2020-11-20 12:16:46',0,'2020-11-20 12:16:46',0),(11,2,NULL,2,'listQuestionGroups','Group list','Group list','List question groups','th-list','fontawesome','','admin/survey/sa/listquestiongroups','','','','','surveycontent','read','{\"render\": { \"link\": {\"data\": {\"surveyid\": [\"survey\",\"sid\"]}}}}','','en-GB',1,1,'2020-11-20 12:16:46',0,'2020-11-20 12:16:46',0),(12,2,NULL,3,'responses','Responses','Responses','Responses','icon-browse','iconclass','','admin/responses/sa/browse/','','','','','responses','read','{\"render\": {\"isActive\": true, \"link\": {\"data\": {\"surveyid\": [\"survey\", \"sid\"]}}}}','','en-GB',1,1,'2020-11-20 12:16:46',0,'2020-11-20 12:16:46',0),(13,2,NULL,4,'participants','Survey participants','Survey participants','Go to survey participant and token settings','user','fontawesome','','admin/tokens/sa/index/','','','','','surveysettings','update','{\"render\": { \"link\": {\"data\": {\"surveyid\": [\"survey\",\"sid\"]}}}}','','en-GB',1,1,'2020-11-20 12:16:46',0,'2020-11-20 12:16:46',0),(14,2,NULL,5,'statistics','Statistics','Statistics','Statistics','bar-chart','fontawesome','','admin/statistics/sa/index/','','','','','statistics','read','{\"render\": {\"isActive\": true, \"link\": {\"data\": {\"surveyid\": [\"survey\", \"sid\"]}}}}','','en-GB',1,1,'2020-11-20 12:16:46',0,'2020-11-20 12:16:46',0),(15,2,NULL,6,'quotas','Edit quotas','Quotas','Edit quotas for this survey.','tasks','fontawesome','','admin/quotas/sa/index/','','','','','quotas','read','{\"render\": { \"link\": {\"data\": {\"surveyid\": [\"survey\",\"sid\"]}}}}','','en-GB',0,1,'2020-11-20 12:16:46',0,'2020-11-20 12:16:46',0),(16,2,NULL,7,'assessments','Edit assessments','Assessments','Edit and look at the assessements for this survey.','comment-o','fontawesome','','admin/assessments/sa/index/','','','','','assessments','read','{\"render\": { \"link\": {\"data\": {\"surveyid\": [\"survey\",\"sid\"]}}}}','','en-GB',0,1,'2020-11-20 12:16:46',0,'2020-11-20 12:16:46',0),(17,2,NULL,8,'surveypermissions','Edit survey permissions','Survey permissions','Edit permissions for this survey','lock','fontawesome','','admin/surveypermission/sa/view/','','','','','surveysecurity','read','{\"render\": { \"link\": {\"data\": {\"surveyid\": [\"survey\",\"sid\"]}}}}','','en-GB',0,1,'2020-11-20 12:16:46',0,'2020-11-20 12:16:46',0),(18,2,NULL,9,'emailtemplates','Email templates','Email templates','Edit the templates for invitation, reminder and registration emails','envelope-square','fontawesome','','admin/emailtemplates/sa/index/','','','','','surveylocale','read','{\"render\": { \"link\": {\"data\": {\"surveyid\": [\"survey\",\"sid\"]}}}}','','en-GB',0,1,'2020-11-20 12:16:46',0,'2020-11-20 12:16:46',0),(19,2,NULL,10,'panelintegration','Edit survey panel integration','Panel integration','Define panel integrations for your survey','link','fontawesome','','','updatesurveylocalesettings','editLocalSettings_main_view','/admin/survey/subview/accordion/_integration_panel','','surveylocale','read','{\"render\": {\"link\": { \"pjaxed\": false}}}','_tabPanelIntegration','en-GB',0,1,'2020-11-20 12:16:46',0,'2020-11-20 12:16:46',0),(20,2,NULL,11,'resources','Add/edit resources (files/images) for this survey','Resources','Add/edit resources (files/images) for this survey','file','fontawesome','','admin/filemanager','','','','','surveylocale','read','{\"render\": { \"link\": {\"data\": {\"surveyid\": [\"survey\",\"sid\"]}}}}','_tabResourceManagement','en-GB',0,1,'2020-11-20 12:16:46',0,'2020-11-20 12:16:46',0),(21,2,NULL,12,'plugins','Simple plugin settings','Simple plugins','Edit simple plugin settings','plug','fontawesome','','','updatesurveylocalesettings','editLocalSettings_main_view','/admin/survey/subview/accordion/_plugins_panel','','surveysettings','read','{\"render\": {\"link\": {\"data\": {\"surveyid\": [\"survey\",\"sid\"]}}}}','_pluginTabSurvey','en-GB',0,1,'2020-11-20 12:16:46',0,'2020-11-20 12:16:46',0),(22,3,NULL,1,'activateSurvey','Activate survey','Activate survey','Activate survey','play','fontawesome','','admin/survey/sa/activate','','','','','surveyactivation','update','{\"render\": {\"isActive\": false, \"link\": {\"data\": {\"surveyid\": [\"survey\",\"sid\"]}}}}','','en-GB',1,1,'2020-11-20 12:16:46',0,'2020-11-20 12:16:46',0),(23,3,NULL,2,'deactivateSurvey','Stop this survey','Stop this survey','Stop this survey','stop','fontawesome','','admin/survey/sa/deactivate','','','','','surveyactivation','update','{\"render\": {\"isActive\": true, \"link\": {\"data\": {\"surveyid\": [\"survey\",\"sid\"]}}}}','','en-GB',1,1,'2020-11-20 12:16:46',0,'2020-11-20 12:16:46',0),(24,3,NULL,3,'testSurvey','Go to survey','Go to survey','Go to survey','cog','fontawesome','','survey/index/','','','','','','','{\"render\": {\"link\": {\"external\": true, \"data\": {\"sid\": [\"survey\",\"sid\"], \"newtest\": \"Y\", \"lang\": [\"survey\",\"language\"]}}}}','','en-GB',1,1,'2020-11-20 12:16:46',0,'2020-11-20 12:16:46',0),(25,3,NULL,4,'surveyLogicFile','Survey logic file','Survey logic file','Survey logic file','sitemap','fontawesome','','admin/expressions/sa/survey_logic_file/','','','','','surveycontent','read','{\"render\": { \"link\": {\"data\": {\"sid\": [\"survey\",\"sid\"]}}}}','','en-GB',1,1,'2020-11-20 12:16:46',0,'2020-11-20 12:16:46',0),(26,3,NULL,5,'cpdb','Central participant database','Central participant database','Central participant database','users','fontawesome','','admin/participants/sa/displayParticipants','','','','','tokens','read','{\"render\": {\"link\": {}}}','','en-GB',1,1,'2020-11-20 12:16:46',0,'2020-11-20 12:16:46',0);
/*!40000 ALTER TABLE `lsud_surveymenu_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_surveys`
--

DROP TABLE IF EXISTS `lsud_surveys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_surveys` (
  `sid` int(11) NOT NULL,
  `owner_id` int(11) NOT NULL,
  `gsid` int(11) DEFAULT '1',
  `admin` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `expires` datetime DEFAULT NULL,
  `startdate` datetime DEFAULT NULL,
  `adminemail` varchar(254) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `anonymized` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `faxto` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `format` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `savetimings` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `template` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'default',
  `language` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `additional_languages` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `datestamp` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `usecookie` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `allowregister` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `allowsave` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `autonumber_start` int(11) NOT NULL DEFAULT '0',
  `autoredirect` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `allowprev` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `printanswers` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `ipaddr` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `ipanonymize` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `refurl` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `datecreated` datetime DEFAULT NULL,
  `showsurveypolicynotice` int(11) DEFAULT '0',
  `publicstatistics` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `publicgraphs` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `listpublic` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `htmlemail` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `sendconfirmation` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `tokenanswerspersistence` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `assessments` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `usecaptcha` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `usetokens` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `bounce_email` varchar(254) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attributedescriptions` text COLLATE utf8mb4_unicode_ci,
  `emailresponseto` text COLLATE utf8mb4_unicode_ci,
  `emailnotificationto` text COLLATE utf8mb4_unicode_ci,
  `tokenlength` int(11) NOT NULL DEFAULT '15',
  `showxquestions` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT 'Y',
  `showgroupinfo` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT 'B',
  `shownoanswer` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT 'Y',
  `showqnumcode` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT 'X',
  `bouncetime` int(11) DEFAULT NULL,
  `bounceprocessing` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT 'N',
  `bounceaccounttype` varchar(4) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bounceaccounthost` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bounceaccountpass` text COLLATE utf8mb4_unicode_ci,
  `bounceaccountencryption` varchar(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bounceaccountuser` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `showwelcome` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT 'Y',
  `showprogress` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT 'Y',
  `questionindex` int(11) NOT NULL DEFAULT '0',
  `navigationdelay` int(11) NOT NULL DEFAULT '0',
  `nokeyboard` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT 'N',
  `alloweditaftercompletion` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT 'N',
  `googleanalyticsstyle` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `googleanalyticsapikey` varchar(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tokenencryptionoptions` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`sid`),
  KEY `lsud_idx1_surveys` (`owner_id`),
  KEY `lsud_idx2_surveys` (`gsid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_surveys`
--

LOCK TABLES `lsud_surveys` WRITE;
/*!40000 ALTER TABLE `lsud_surveys` DISABLE KEYS */;
INSERT INTO `lsud_surveys` (`sid`, `owner_id`, `gsid`, `admin`, `active`, `expires`, `startdate`, `adminemail`, `anonymized`, `faxto`, `format`, `savetimings`, `template`, `language`, `additional_languages`, `datestamp`, `usecookie`, `allowregister`, `allowsave`, `autonumber_start`, `autoredirect`, `allowprev`, `printanswers`, `ipaddr`, `ipanonymize`, `refurl`, `datecreated`, `showsurveypolicynotice`, `publicstatistics`, `publicgraphs`, `listpublic`, `htmlemail`, `sendconfirmation`, `tokenanswerspersistence`, `assessments`, `usecaptcha`, `usetokens`, `bounce_email`, `attributedescriptions`, `emailresponseto`, `emailnotificationto`, `tokenlength`, `showxquestions`, `showgroupinfo`, `shownoanswer`, `showqnumcode`, `bouncetime`, `bounceprocessing`, `bounceaccounttype`, `bounceaccounthost`, `bounceaccountpass`, `bounceaccountencryption`, `bounceaccountuser`, `showwelcome`, `showprogress`, `questionindex`, `navigationdelay`, `nokeyboard`, `alloweditaftercompletion`, `googleanalyticsstyle`, `googleanalyticsapikey`, `tokenencryptionoptions`) VALUES (855621,1,1,'inherit','Y',NULL,NULL,'santiago.pesantez@integra-ec.com','N','','I','Y','udla_vanilla','es','','Y','I','I','I',1,'I','I','I','Y','N','Y','2020-11-20 12:36:53',0,'I','I','I','I','I','I','I','E','N','inherit',NULL,'inherit','inherit',-1,'N','I','N','I',NULL,'N',NULL,NULL,NULL,NULL,NULL,'I','I',-1,-1,'I','I','0',NULL,'');
/*!40000 ALTER TABLE `lsud_surveys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_surveys_groups`
--

DROP TABLE IF EXISTS `lsud_surveys_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_surveys_groups` (
  `gsid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `template` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT 'default',
  `description` text COLLATE utf8mb4_unicode_ci,
  `sortorder` int(11) NOT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  PRIMARY KEY (`gsid`),
  KEY `lsud_idx1_surveys_groups` (`name`),
  KEY `lsud_idx2_surveys_groups` (`title`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_surveys_groups`
--

LOCK TABLES `lsud_surveys_groups` WRITE;
/*!40000 ALTER TABLE `lsud_surveys_groups` DISABLE KEYS */;
INSERT INTO `lsud_surveys_groups` (`gsid`, `name`, `title`, `template`, `description`, `sortorder`, `owner_id`, `parent_id`, `created`, `modified`, `created_by`) VALUES (1,'default','Default',NULL,'Default survey group',0,1,NULL,'2020-11-20 12:16:46','2020-11-20 12:16:46',1);
/*!40000 ALTER TABLE `lsud_surveys_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_surveys_groupsettings`
--

DROP TABLE IF EXISTS `lsud_surveys_groupsettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_surveys_groupsettings` (
  `gsid` int(11) NOT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `admin` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `adminemail` varchar(254) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `anonymized` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `format` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `savetimings` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `template` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'default',
  `datestamp` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `usecookie` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `allowregister` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `allowsave` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `autonumber_start` int(11) DEFAULT '0',
  `autoredirect` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `allowprev` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `printanswers` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `ipaddr` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `ipanonymize` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `refurl` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `showsurveypolicynotice` int(11) DEFAULT '0',
  `publicstatistics` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `publicgraphs` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `listpublic` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `htmlemail` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `sendconfirmation` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `tokenanswerspersistence` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `assessments` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `usecaptcha` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `bounce_email` varchar(254) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attributedescriptions` text COLLATE utf8mb4_unicode_ci,
  `emailresponseto` text COLLATE utf8mb4_unicode_ci,
  `emailnotificationto` text COLLATE utf8mb4_unicode_ci,
  `tokenlength` int(11) DEFAULT '15',
  `showxquestions` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT 'Y',
  `showgroupinfo` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT 'B',
  `shownoanswer` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT 'Y',
  `showqnumcode` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT 'X',
  `showwelcome` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT 'Y',
  `showprogress` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT 'Y',
  `questionindex` int(11) DEFAULT '0',
  `navigationdelay` int(11) DEFAULT '0',
  `nokeyboard` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT 'N',
  `alloweditaftercompletion` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT 'N',
  PRIMARY KEY (`gsid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_surveys_groupsettings`
--

LOCK TABLES `lsud_surveys_groupsettings` WRITE;
/*!40000 ALTER TABLE `lsud_surveys_groupsettings` DISABLE KEYS */;
INSERT INTO `lsud_surveys_groupsettings` (`gsid`, `owner_id`, `admin`, `adminemail`, `anonymized`, `format`, `savetimings`, `template`, `datestamp`, `usecookie`, `allowregister`, `allowsave`, `autonumber_start`, `autoredirect`, `allowprev`, `printanswers`, `ipaddr`, `ipanonymize`, `refurl`, `showsurveypolicynotice`, `publicstatistics`, `publicgraphs`, `listpublic`, `htmlemail`, `sendconfirmation`, `tokenanswerspersistence`, `assessments`, `usecaptcha`, `bounce_email`, `attributedescriptions`, `emailresponseto`, `emailnotificationto`, `tokenlength`, `showxquestions`, `showgroupinfo`, `shownoanswer`, `showqnumcode`, `showwelcome`, `showprogress`, `questionindex`, `navigationdelay`, `nokeyboard`, `alloweditaftercompletion`) VALUES (0,1,'Administrator','your-email@example.net','N','G','N','fruity','N','N','N','Y',0,'N','N','N','N','N','N',0,'N','N','N','N','Y','N','N','N',NULL,NULL,NULL,NULL,15,'Y','B','Y','X','Y','Y',0,0,'N','N'),(1,-1,'inherit','inherit','I','I','I','inherit','I','I','I','I',0,'I','I','I','I','I','I',0,'I','I','I','I','I','I','I','E','inherit',NULL,'inherit','inherit',-1,'I','I','I','I','I','I',-1,-1,'I','I');
/*!40000 ALTER TABLE `lsud_surveys_groupsettings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_surveys_languagesettings`
--

DROP TABLE IF EXISTS `lsud_surveys_languagesettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_surveys_languagesettings` (
  `surveyls_survey_id` int(11) NOT NULL,
  `surveyls_language` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en',
  `surveyls_title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `surveyls_description` text COLLATE utf8mb4_unicode_ci,
  `surveyls_welcometext` text COLLATE utf8mb4_unicode_ci,
  `surveyls_endtext` text COLLATE utf8mb4_unicode_ci,
  `surveyls_policy_notice` text COLLATE utf8mb4_unicode_ci,
  `surveyls_policy_error` text COLLATE utf8mb4_unicode_ci,
  `surveyls_policy_notice_label` varchar(192) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `surveyls_url` text COLLATE utf8mb4_unicode_ci,
  `surveyls_urldescription` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `surveyls_email_invite_subj` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `surveyls_email_invite` text COLLATE utf8mb4_unicode_ci,
  `surveyls_email_remind_subj` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `surveyls_email_remind` text COLLATE utf8mb4_unicode_ci,
  `surveyls_email_register_subj` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `surveyls_email_register` text COLLATE utf8mb4_unicode_ci,
  `surveyls_email_confirm_subj` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `surveyls_email_confirm` text COLLATE utf8mb4_unicode_ci,
  `surveyls_dateformat` int(11) NOT NULL DEFAULT '1',
  `surveyls_attributecaptions` text COLLATE utf8mb4_unicode_ci,
  `email_admin_notification_subj` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_admin_notification` text COLLATE utf8mb4_unicode_ci,
  `email_admin_responses_subj` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_admin_responses` text COLLATE utf8mb4_unicode_ci,
  `surveyls_numberformat` int(11) NOT NULL DEFAULT '0',
  `attachments` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`surveyls_survey_id`,`surveyls_language`),
  KEY `lsud_idx1_surveys_languagesettings` (`surveyls_title`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_surveys_languagesettings`
--

LOCK TABLES `lsud_surveys_languagesettings` WRITE;
/*!40000 ALTER TABLE `lsud_surveys_languagesettings` DISABLE KEYS */;
INSERT INTO `lsud_surveys_languagesettings` (`surveyls_survey_id`, `surveyls_language`, `surveyls_title`, `surveyls_description`, `surveyls_welcometext`, `surveyls_endtext`, `surveyls_policy_notice`, `surveyls_policy_error`, `surveyls_policy_notice_label`, `surveyls_url`, `surveyls_urldescription`, `surveyls_email_invite_subj`, `surveyls_email_invite`, `surveyls_email_remind_subj`, `surveyls_email_remind`, `surveyls_email_register_subj`, `surveyls_email_register`, `surveyls_email_confirm_subj`, `surveyls_email_confirm`, `surveyls_dateformat`, `surveyls_attributecaptions`, `email_admin_notification_subj`, `email_admin_notification`, `email_admin_responses_subj`, `email_admin_responses`, `surveyls_numberformat`, `attachments`) VALUES (855621,'es','Percepción de riesgo COVID-19','<p style=\"text-align:justify;\">¡Bienvenida/o a la encuesta sobre percepción de riesgo sobre COVID-19 en Ecuador!</p><p style=\"text-align:justify;\">La Universidad de las Américas (UDLA) está realizando una investigación cuyo objetivo es determinar cuál es la percepción de riesgo que tienen los trabajadores de la salud s con relación a la pandemia de COVID-19.</p><p style=\"text-align:justify;\">Con su participación se pretende generar información que ayude al diseño de mejores políticas de salud en relación con la ocurrencia de este tipo de fenómeno. &nbsp;</p><p style=\"text-align:justify;\">Su participación en esta encuesta es voluntaria. Usted puede no responder cualquier pregunta o dar por terminada la encuesta cuando desee. &nbsp;No recibirá compensación económica alguna por completar la misma.</p><p style=\"text-align:justify;\">Se han tomado todas las medidas posibles para proteger su privacidad y sus respuestas solo se utilizarán para esta investigación. Su identidad nunca será revelada en los análisis o publicaciones científicas de este estudio. Toda la información se almacenará en bases de datos de forma anónima.</p><p style=\"text-align:justify;\">Esta encuesta toma máximo 30 minutos de su tiempo en completar. &nbsp;</p><p style=\"text-align:justify;\">Soy Martha Fors y si tiene cualquier duda o si necesita cualquier información adicional me puede contactar al correo martha.fors@udla.edu.ec.</p><p style=\"text-align:justify;\">¡Muchas gracias por su participación!</p><p style=\"text-align:right;\">Si está de acuerdo en participar en este estudio, por favor, haga clic en \"SIGUIENTE\"</p>','','<p>La Universidad de Las Américas le agradece por su participación en este estudio. La información brindada por Ud. es muy valiosa se utilizará únicamente para fines investigativos.&nbsp;</p><p>Valoramos su privacidad y el tiempo que ha dedicado en contestar esta encuesta.&nbsp;</p><p>¡Muchas gracias!</p>',NULL,NULL,NULL,'','','Invitación para participar en una encuesta','Estimado/a {FIRSTNAME} {LASTNAME}:Ha sido invitado a participar en la siguiente encuesta:«{SURVEYNAME}»«{SURVEYDESCRIPTION}»Para hacerlo, por favor pulse en el siguiente enlace:{SURVEYURL}¡Muchas gracias por su interés y colaboración!Atentamente,{ADMINNAME} ({ADMINEMAIL})Si no desea participar en esta encuesta y tampoco desea recibir más invitaciones a la misma, por favor, pulse en el siguiente enlace:{OPTOUTURL}Si usted se encuentra en la lista negra de usuarios, pero quiere participar en esta encuesta y quiere recibir invitaciones, por favor haga click en el siguiente enlace:{OPTINURL}','Recordatorio para participar en una encuesta','Estimado/a {FIRSTNAME} {LASTNAME}:Recientemente se le invitó a participar en la encuesta de título«{SURVEYNAME}»«{SURVEYDESCRIPTION}»Advertimos que aún no la ha completado, y de la forma más atenta queríamos recordarle que todavía se encuentra disponible si desea participar.Para hacerlo, por favor pulse en el siguiente enlace:{SURVEYURL}Nuevamente le agradecemos su interés y colaboración.Atentamente,{ADMINNAME} ({ADMINEMAIL})Si no desea participar en esta encuesta y tampoco desea recibir más invitaciones a la misma, por favor, pulse en el siguiente enlace:{OPTOUTURL}','Confirmación de registro en la encuesta','Estimado/a {FIRSTNAME} {LASTNAME}:Usted, o alguien utilizando su dirección de correo electrónico, se ha registrado para participar en una encuesta en línea titulada «{SURVEYNAME}»«{SURVEYDESCRIPTION}»Para completarla, pulse en la siguiente dirección:{SURVEYURL}Si tiene cualquier duda con respecto a la encuesta, o si no se registró para participar y cree que este correo es un error, por favor, póngase en contacto con {ADMINNAME} en {ADMINEMAIL}.','Confirmación de su participación en nuestra encuesta','Estimado/a {FIRSTNAME} {LASTNAME}:Este correo es para confirmarle que ha completado la encuesta titulada \"{SURVEYNAME}\" y sus respuestas han quedado correctamente guardadas. ¡Muchas gracias por su participación!.Si tiene alguna duda o consulta adicional, por favor póngase en contacto con {ADMINNAME} en {ADMINEMAIL}.Reciba un cordial saludo,{ADMINNAME}',5,NULL,'Envío de respuestas de la encuesta {SURVEYNAME}','Hola!Una nueva respuesta ha sido concluida en su encuesta \'{SURVEYNAME}\'.Pulse el siguiente enlace para ver la respuesta individual:{VIEWRESPONSEURL}Pulse el siguiente enlace para editar la respuesta individual:{EDITRESPONSEURL}Ver estadísticas pulsando el siguiente enlace:{STATISTICSURL}','Enviar los resultados de las respuestas en la encuesta {SURVEYNAME}','Hola:Una nueva respuesta ha sido concluida en su encuesta \'{SURVEYNAME}\'.Pulse el siguiente enlace para ver la respuesta individual:{VIEWRESPONSEURL}Pulse el siguiente enlace para editar la respuesta individual:{EDITRESPONSEURL}Ver estadísticas pulsando el siguiente enlace:{STATISTICSURL}Estas son las respuestas dadas por el/la encuestado/a:{ANSWERTABLE}',1,NULL);
/*!40000 ALTER TABLE `lsud_surveys_languagesettings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_template_configuration`
--

DROP TABLE IF EXISTS `lsud_template_configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_template_configuration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sid` int(11) DEFAULT NULL,
  `gsid` int(11) DEFAULT NULL,
  `uid` int(11) DEFAULT NULL,
  `files_css` text COLLATE utf8mb4_unicode_ci,
  `files_js` text COLLATE utf8mb4_unicode_ci,
  `files_print_css` text COLLATE utf8mb4_unicode_ci,
  `options` text COLLATE utf8mb4_unicode_ci,
  `cssframework_name` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cssframework_css` text COLLATE utf8mb4_unicode_ci,
  `cssframework_js` text COLLATE utf8mb4_unicode_ci,
  `packages_to_load` text COLLATE utf8mb4_unicode_ci,
  `packages_ltr` text COLLATE utf8mb4_unicode_ci,
  `packages_rtl` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `lsud_idx1_template_configuration` (`template_name`),
  KEY `lsud_idx2_template_configuration` (`sid`),
  KEY `lsud_idx3_template_configuration` (`gsid`),
  KEY `lsud_idx4_template_configuration` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_template_configuration`
--

LOCK TABLES `lsud_template_configuration` WRITE;
/*!40000 ALTER TABLE `lsud_template_configuration` DISABLE KEYS */;
INSERT INTO `lsud_template_configuration` (`id`, `template_name`, `sid`, `gsid`, `uid`, `files_css`, `files_js`, `files_print_css`, `options`, `cssframework_name`, `cssframework_css`, `cssframework_js`, `packages_to_load`, `packages_ltr`, `packages_rtl`) VALUES (1,'vanilla',NULL,NULL,NULL,'{\"add\":[\"css/ajaxify.css\",\"css/theme.css\",\"css/custom.css\"]}','{\"add\":[\"scripts/theme.js\",\"scripts/ajaxify.js\",\"scripts/custom.js\"]}','{\"add\":[\"css/print_theme.css\"]}','{\"ajaxmode\":\"off\",\"brandlogo\":\"on\",\"container\":\"on\", \"hideprivacyinfo\": \"off\", \"brandlogofile\":\"themes/survey/vanilla/files/logo.png\",\"font\":\"noto\", \"showpopups\":\"1\", \"showclearall\":\"off\", \"questionhelptextposition\":\"top\"}','bootstrap','{}','','{\"add\":[\"pjax\",\"font-noto\",\"moment\"]}',NULL,NULL),(2,'fruity',NULL,NULL,NULL,'{\"add\":[\"css/ajaxify.css\",\"css/animate.css\",\"css/variations/sea_green.css\",\"css/theme.css\",\"css/custom.css\"]}','{\"add\":[\"scripts/theme.js\",\"scripts/ajaxify.js\",\"scripts/custom.js\"]}','{\"add\":[\"css/print_theme.css\"]}','{\"ajaxmode\":\"off\",\"brandlogo\":\"on\",\"brandlogofile\":\"themes/survey/fruity/files/logo.png\",\"container\":\"on\",\"backgroundimage\":\"off\",\"backgroundimagefile\":null,\"animatebody\":\"off\",\"bodyanimation\":\"fadeInRight\",\"bodyanimationduration\":\"500\",\"animatequestion\":\"off\",\"questionanimation\":\"flipInX\",\"questionanimationduration\":\"500\",\"animatealert\":\"off\",\"alertanimation\":\"shake\",\"alertanimationduration\":\"500\",\"font\":\"noto\",\"bodybackgroundcolor\":\"#ffffff\",\"fontcolor\":\"#444444\",\"questionbackgroundcolor\":\"#ffffff\",\"questionborder\":\"on\",\"questioncontainershadow\":\"on\",\"checkicon\":\"f00c\",\"animatecheckbox\":\"on\",\"checkboxanimation\":\"rubberBand\",\"checkboxanimationduration\":\"500\",\"animateradio\":\"on\",\"radioanimation\":\"zoomIn\",\"radioanimationduration\":\"500\",\"zebrastriping\":\"off\",\"stickymatrixheaders\":\"off\",\"greyoutselected\":\"off\",\"hideprivacyinfo\":\"off\",\"crosshover\":\"off\",\"showpopups\":\"1\", \"showclearall\":\"off\", \"questionhelptextposition\":\"top\",\"notables\":\"1\"}','bootstrap','{}','','{\"add\":[\"pjax\",\"font-noto\",\"moment\"]}',NULL,NULL),(3,'bootswatch',NULL,NULL,NULL,'{\"add\":[\"css/ajaxify.css\",\"css/theme.css\",\"css/custom.css\"]}','{\"add\":[\"scripts/theme.js\",\"scripts/ajaxify.js\",\"scripts/custom.js\"]}','{\"add\":[\"css/print_theme.css\"]}','{\"ajaxmode\":\"off\",\"brandlogo\":\"on\",\"container\":\"on\",\"brandlogofile\":\"themes/survey/bootswatch/files/logo.png\", \"showpopups\":\"1\", \"showclearall\":\"off\", \"questionhelptextposition\":\"top\"}','bootstrap','{\"replace\":[[\"css/bootstrap.css\",\"css/variations/flatly.min.css\"]]}','','{\"add\":[\"pjax\",\"font-noto\",\"moment\"]}',NULL,NULL),(4,'fruity',855621,NULL,NULL,'inherit','inherit','inherit','inherit','inherit','inherit','inherit','inherit',NULL,NULL),(5,'fruity',NULL,1,NULL,'inherit','inherit','inherit','inherit','inherit','inherit','inherit','inherit',NULL,NULL),(6,'vanilla',855621,NULL,NULL,'inherit','inherit','inherit','{\"general_inherit\":1,\"font\":\"inherit\",\"brandlogofile\":\"themes/survey/vanilla/files/logo-udla.png\",\"container\":\"inherit\",\"hideprivacyinfo\":\"inherit\",\"showclearall\":\"inherit\",\"questionhelptextposition\":\"inherit\",\"showpopups\":\"inherit\",\"fixnumauto\":\"inherit\",\"brandlogo\":\"on\",\"generalInherit\":null}','inherit','inherit','inherit','inherit',NULL,NULL),(7,'vanilla',NULL,1,NULL,'inherit','inherit','inherit','inherit','inherit','inherit','inherit','inherit',NULL,NULL),(8,'udla_vanilla',NULL,NULL,NULL,'{\"add\":[\"css\\/base.css\",\"css\\/theme.css\",\"css\\/noTablesOnMobile.css\",\"css\\/custom.css\"]}','{\"add\":[\"scripts\\/theme.js\",\"scripts\\/custom.js\"]}','{\"add\":[\"css\\/print_theme.css\"]}','{\"animatebody\":\"off\",\"hideprivacyinfo\":\"off\",\"container\":\"on\",\"showpopups\":\"1\",\"showclearall\":\"off\",\"questionhelptextposition\":\"top\",\"fixnumauto\":\"off\",\"brandlogo\":\"on\",\"brandlogofile\":\"themes\\/survey\\/vanilla\\/files\\/logo.png\",\"font\":\"noto\\n            \\n       \"}','bootstrap','{}','[]','{\"add\":[\"pjax\",\"moment\",\"font-noto\"]}',NULL,NULL),(9,'udla_vanilla',855621,NULL,NULL,'inherit','inherit','inherit','{\"general_inherit\":1,\"font\":\"inherit\",\"brandlogofile\":\"upload/themes/survey/udla_vanilla/files/logo-udla.png\",\"container\":\"inherit\",\"hideprivacyinfo\":\"inherit\",\"showclearall\":\"inherit\",\"questionhelptextposition\":\"inherit\",\"showpopups\":\"inherit\",\"fixnumauto\":\"inherit\",\"brandlogo\":\"on\",\"generalInherit\":null}','inherit','inherit','inherit','inherit',NULL,NULL),(10,'udla_vanilla',NULL,1,NULL,'inherit','inherit','inherit','inherit','inherit','inherit','inherit','inherit',NULL,NULL);
/*!40000 ALTER TABLE `lsud_template_configuration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_templates`
--

DROP TABLE IF EXISTS `lsud_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `folder` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation_date` datetime DEFAULT NULL,
  `author` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `author_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `author_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `copyright` text COLLATE utf8mb4_unicode_ci,
  `license` text COLLATE utf8mb4_unicode_ci,
  `version` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `api_version` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `view_folder` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `files_folder` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `last_update` datetime DEFAULT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `extends` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lsud_idx1_templates` (`name`),
  KEY `lsud_idx2_templates` (`title`),
  KEY `lsud_idx3_templates` (`owner_id`),
  KEY `lsud_idx4_templates` (`extends`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_templates`
--

LOCK TABLES `lsud_templates` WRITE;
/*!40000 ALTER TABLE `lsud_templates` DISABLE KEYS */;
INSERT INTO `lsud_templates` (`id`, `name`, `folder`, `title`, `creation_date`, `author`, `author_email`, `author_url`, `copyright`, `license`, `version`, `api_version`, `view_folder`, `files_folder`, `description`, `last_update`, `owner_id`, `extends`) VALUES (1,'vanilla','vanilla','Vanilla Theme','2020-11-20 12:16:46','Louis Gac','louis.gac@limesurvey.org','https://www.limesurvey.org/','Copyright (C) 2007-2019 The LimeSurvey Project Team\\r\\nAll rights reserved.','License: GNU/GPL License v2 or later, see LICENSE.php\\r\\n\\r\\nLimeSurvey is free software. This version may have been modified pursuant to the GNU General Public License, and as distributed it includes or is derivative of works licensed under the GNU General Public License or other free or open source software licenses. See COPYRIGHT.php for copyright notices and details.','3.0','3.0','views','files','<strong>LimeSurvey Bootstrap Vanilla Survey Theme</strong><br>A clean and simple base that can be used by developers to create their own Bootstrap based theme.',NULL,1,''),(2,'fruity','fruity','Fruity Theme','2020-11-20 12:16:46','Louis Gac','louis.gac@limesurvey.org','https://www.limesurvey.org/','Copyright (C) 2007-2019 The LimeSurvey Project Team\\r\\nAll rights reserved.','License: GNU/GPL License v2 or later, see LICENSE.php\\r\\n\\r\\nLimeSurvey is free software. This version may have been modified pursuant to the GNU General Public License, and as distributed it includes or is derivative of works licensed under the GNU General Public License or other free or open source software licenses. See COPYRIGHT.php for copyright notices and details.','3.0','3.0','views','files','<strong>LimeSurvey Fruity Theme</strong><br>A fruity theme for a flexible use. This theme offers monochromes variations and many options for easy customizations.',NULL,1,'vanilla'),(3,'bootswatch','bootswatch','Bootswatch Theme','2020-11-20 12:16:46','Louis Gac','louis.gac@limesurvey.org','https://www.limesurvey.org/','Copyright (C) 2007-2019 The LimeSurvey Project Team\\r\\nAll rights reserved.','License: GNU/GPL License v2 or later, see LICENSE.php\\r\\n\\r\\nLimeSurvey is free software. This version may have been modified pursuant to the GNU General Public License, and as distributed it includes or is derivative of works licensed under the GNU General Public License or other free or open source software licenses. See COPYRIGHT.php for copyright notices and details.','3.0','3.0','views','files','<strong>LimeSurvey Bootwatch Theme</strong><br>Based on BootsWatch Themes: <a href=\"https://bootswatch.com/3/\"\">Visit BootsWatch page</a> ',NULL,1,'vanilla'),(4,'udla_vanilla','udla_vanilla','udla_vanilla','2020-11-20 15:35:21','admin','','',NULL,NULL,NULL,'3.0','views','files','<strong>LimeSurvey Bootstrap Vanilla Survey Theme</strong><br>A clean and simple base that can be used by developers to create their own Bootstrap based theme.',NULL,1,'vanilla');
/*!40000 ALTER TABLE `lsud_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_tutorial_entries`
--

DROP TABLE IF EXISTS `lsud_tutorial_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_tutorial_entries` (
  `teid` int(11) NOT NULL AUTO_INCREMENT,
  `ordering` int(11) DEFAULT NULL,
  `title` text COLLATE utf8mb4_unicode_ci,
  `content` text COLLATE utf8mb4_unicode_ci,
  `settings` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`teid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_tutorial_entries`
--

LOCK TABLES `lsud_tutorial_entries` WRITE;
/*!40000 ALTER TABLE `lsud_tutorial_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `lsud_tutorial_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_tutorial_entry_relation`
--

DROP TABLE IF EXISTS `lsud_tutorial_entry_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_tutorial_entry_relation` (
  `teid` int(11) NOT NULL,
  `tid` int(11) NOT NULL,
  `uid` int(11) DEFAULT NULL,
  `sid` int(11) DEFAULT NULL,
  PRIMARY KEY (`teid`,`tid`),
  KEY `lsud_idx1_tutorial_entry_relation` (`uid`),
  KEY `lsud_idx2_tutorial_entry_relation` (`sid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_tutorial_entry_relation`
--

LOCK TABLES `lsud_tutorial_entry_relation` WRITE;
/*!40000 ALTER TABLE `lsud_tutorial_entry_relation` DISABLE KEYS */;
/*!40000 ALTER TABLE `lsud_tutorial_entry_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_tutorials`
--

DROP TABLE IF EXISTS `lsud_tutorials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_tutorials` (
  `tid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(192) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `active` int(11) DEFAULT '0',
  `settings` text COLLATE utf8mb4_unicode_ci,
  `permission` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `permission_grade` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`tid`),
  UNIQUE KEY `lsud_idx1_tutorials` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_tutorials`
--

LOCK TABLES `lsud_tutorials` WRITE;
/*!40000 ALTER TABLE `lsud_tutorials` DISABLE KEYS */;
/*!40000 ALTER TABLE `lsud_tutorials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_user_groups`
--

DROP TABLE IF EXISTS `lsud_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_user_groups` (
  `ugid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` int(11) NOT NULL,
  PRIMARY KEY (`ugid`),
  UNIQUE KEY `lsud_idx1_user_groups` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_user_groups`
--

LOCK TABLES `lsud_user_groups` WRITE;
/*!40000 ALTER TABLE `lsud_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `lsud_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_user_in_groups`
--

DROP TABLE IF EXISTS `lsud_user_in_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_user_in_groups` (
  `ugid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  PRIMARY KEY (`ugid`,`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_user_in_groups`
--

LOCK TABLES `lsud_user_in_groups` WRITE;
/*!40000 ALTER TABLE `lsud_user_in_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `lsud_user_in_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_user_in_permissionrole`
--

DROP TABLE IF EXISTS `lsud_user_in_permissionrole`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_user_in_permissionrole` (
  `ptid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  PRIMARY KEY (`ptid`,`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_user_in_permissionrole`
--

LOCK TABLES `lsud_user_in_permissionrole` WRITE;
/*!40000 ALTER TABLE `lsud_user_in_permissionrole` DISABLE KEYS */;
/*!40000 ALTER TABLE `lsud_user_in_permissionrole` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lsud_users`
--

DROP TABLE IF EXISTS `lsud_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lsud_users` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `users_name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `password` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `full_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_id` int(11) NOT NULL,
  `lang` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(192) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `htmleditormode` varchar(7) COLLATE utf8mb4_unicode_ci DEFAULT 'default',
  `templateeditormode` varchar(7) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'default',
  `questionselectormode` varchar(7) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'default',
  `one_time_pw` text COLLATE utf8mb4_unicode_ci,
  `dateformat` int(11) NOT NULL DEFAULT '1',
  `lastLogin` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `lsud_idx1_users` (`users_name`),
  KEY `lsud_idx2_users` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lsud_users`
--

LOCK TABLES `lsud_users` WRITE;
/*!40000 ALTER TABLE `lsud_users` DISABLE KEYS */;
INSERT INTO `lsud_users` (`uid`, `users_name`, `password`, `full_name`, `parent_id`, `lang`, `email`, `htmleditormode`, `templateeditormode`, `questionselectormode`, `one_time_pw`, `dateformat`, `lastLogin`, `created`, `modified`) VALUES (1,'admin','$2y$10$ZUq.PfLWqyq2VwdQKdsNf.3gGgzhbX2a7Zs.5IcZ2mCXqr9ejn9da','Administrador',0,'es','santiago.pesantez@integra-ec.com','default','default','default',NULL,1,'2020-11-22 16:01:24','2020-11-20 12:16:46','2020-11-22 16:01:24');
/*!40000 ALTER TABLE `lsud_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'redequip_limeudl'
--

--
-- Dumping routines for database 'redequip_limeudl'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-11-22 19:51:43
